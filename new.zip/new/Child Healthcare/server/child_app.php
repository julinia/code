<?php
require "../db/db.php";
$Fname = $_POST["fname"];
$Lname = $_POST["lname"];
$Age=$_POST["age"];
$Weight = $_POST["weight"];
$Gender = $_POST["gender"];
$Date = $_POST["date"];
$Fa_name = $_POST["fa_name"];
$Mo_name = $_POST["mo_name"];
$Address = $_POST["address"];
$Mobile_no = $_POST["mobile_no"];
$app_date = $_POST["app_date"];
$patient = $_POST["patient"];
$doc_id = $_POST["doc_id"];


  include_once('../db/dbconnect.php');
    $sql = "SELECT * FROM child_app ORDER BY serial_no DESC Limit 1";
    $res = getDataFromDB($sql);
    $count = count($res);
    if($count == 0){
        $id = 1;
    }
    else{
        foreach($res as $row){
            $id = $row['serial_no']+1;
//           
        }
    }
function check($date,$id){
    
  include_once('../db/dbconnect.php');
     $sql = "SELECT * FROM app_counter WHERE Date = '".$date."' AND DoctorID = '".$id."'";
    $res = getDataFromDB($sql);
    $count = count($res);
    if($count == 0){
        return 0;
    
    }
    else{
        foreach ($res as $row){
            return $row["AppointmentLeft"];
        }
    }
    
}

include_once ('../db/dbconnect.php');
$sql = "SELECT * FROM app_counter WHERE Date = '".$app_date."' AND DoctorID = '".$doc_id."'";
$ch = getDataFromDB($sql);
$count = count($ch);
    if($count == 0){
        $apleft = 6;
    
    }
    else{
        foreach ($ch as $row){
            $apleft = $row["AppointmentLeft"];
        }
    }

if ($apleft != 0){
//include_once ('../db/dbconnect.php');
//    $chsql = "SELECT * FROM child_app WHERE app_date = '".$Date."'";
//    $chresult = getDataFromDB($chsql);
//    foreach($chresult as $chrow){
//        if($chrow['email'] == $_POST['email']){
//            
//        }
//        else{
//            
//        }
//    }
    
    
$query="INSERT INTO `child_app` (`fname`, `lname`,  `age`, `weight`, `gender`, `date`, `fa_name`, `mo_name`,`email`, `address`, `mobile` , `patient` , `app_id` ,`app_date`, `doc_id`) VALUES ('$Fname', '$Lname',  '$Age', '$Weight', '$Gender', '$Date', '$Fa_name', '$Mo_name','".$_POST['email']."', '$Address', '$Mobile_no' , '$patient' , '$id' ,'".$app_date."', '$doc_id')";

$time = "INSERT INTO `app_time`( `app_id`, `doc_id`, `patient_mail`, `patient_phn`, `visit_date`, `visit_sdlNo`, `status`) VALUES ('".$id."','$doc_id','".$_POST['email']."','$Mobile_no','".$app_date."','$id','Unseen')";

if(check($app_date,$doc_id)==0){
    $sql = "INSERT INTO `app_counter`( `DoctorID`, `Date`) VALUES ('$doc_id','".$app_date."')";
}
else{
    $new = check($app_date,$doc_id) - 1;
    $sql = "UPDATE app_counter SET AppointmentLeft = '".$new."' WHERE DoctorID = '".$doc_id."'";
}
if($con->query($query) === TRUE AND $con->query($time) === TRUE AND $con->query($sql) === TRUE){
    echo "Success";
    echo '<br>';
    ?>
<h3>Your Serial No: <span style="color: red"><?php echo 6 - check($app_date,$doc_id); ?></span>. Please be present in time.</h3>
    <?php
}
   else
    {
       
   echo $con->error;       
    }
}
else{
    echo "No schedule today";
}
   
?>
<button style=" height: 200px; width:300px; margin-left:30px;"><li><a href="../appointment/appfpage.php">back</a></li></button>