<?php


// require "../db/db.php";

// function gender($Gender){
//   if($Gender == "Male"){
//     return 1;
//   }
//   elseif($Gender == "Female"){
//     return 2;
//   }
//   else{
//     return "Error";
//   }
// }

// include '../db/dbconnect.php';
// $sql = "SELECT MAX(serial_no) FROM add_doc";
// $mid = getDataFromDB($sql);
// foreach ($mid as $key) {
// $maxid = $key["MAX(serial_no)"];
//   }
//    $id = $maxid+1;

// $Fname = $_POST["fname"];
// $Lname = $_POST["lname"];
// $Email = $_POST["email"];
// $Password = $_POST["password"];
// $Mobile_no = $_POST["mobile_no"];
// $County= $_POST["country"];
// $Gender = $_POST["gender"];
// $Certificate = $_POST["certificate"];
// $Institute = $_POST["institute"];
// $Registration_no = $_POST["registration_no"];
// $Roll_no = $_POST["roll_no"];
// $Passing_year = $_POST["passing_year"];
// $Speciality = $_POST["speciality"];
// $Title = $_POST["title"];
// $Duration = $_POST["duration"];
// $Present_add = $_POST["present_add"];
// $Permanent_add = $_POST["permanent_add"];
// $admission_year = date('Y');


// $gendercode = gender($Gender);


// echo $admission_year.$gendercode.$Roll_no.$id; commentout ei thakbe

// $admin_id = $admission_year.$gendercode.$Roll_no.$id;
//   echo $admin_id;


//  $query="INSERT INTO `add_doc` (`fname`, `id`, `lname`, `email`, `password`, `mobile_no`, `country`, `gender`, `certificate`, `institute`, `registration_no`, `roll_no`, `passing_year`, `speciality`, `title`, `duration`, `present_add`, `permanent_add`) VALUES (' $admin_id', '$Fname', '$Lname', '$Email', '$Password', '$Mobile_no', '$County', '$Gender', '$Certificate ', '$Institute', '$Registration_no', '$Roll_no', '$Passing_year ', '$Speciality', '$Title', '$Duration', '$Present_add', '$Permanent_add')";
 
//  $userquery = "INSERT INTO `users`(`UID`, `Email`, `Password`, `UserRole`, `Status`) VALUES ('$admin_id','$Email','$Password','Doctor','Approved')";
//  if($con->query($query) === TRUE AND $con->query($userquery) === TRUE){
//     echo "Success"; }
//    else
//     {
       
//    echo $con->error;       
//     }

session_start();
include_once('../db/dbconnect.php');
$sql = "SELECT * FROM add_doc ORDER BY serial_no DESC LIMIT 1";
$rest = getDataFromDB($sql);
foreach($rest as $key){
    $id = $key['serial_no'] + 1;
}

require "../db/db.php";

$Fname = $_POST["fname"];
$Lname = $_POST["lname"];
$Email = $_POST["email"];
$Password = md5($_POST["password"]);
$Mobile_no = $_POST["mobile_no"];
$Country= $_POST["country"];
$Gender = $_POST["gender"];

$filename = $_FILES["picture"]["name"];
$tmpname = $_FILES["picture"]["tmp_name"];


$filetype = strtolower(pathinfo($filename,PATHINFO_EXTENSION));
$movefile = '../Image/' . $Email . '.' . $filetype;

$dbfile = 'Image/' . $Email . '.' . $filetype;
move_uploaded_file($tmpname, $movefile);


$Certificate = $_POST["certificate"];
$Institute = $_POST["institute"];
$Registration_no = $_POST["registration_no"];
$Roll_no = $_POST["roll_no"];
$Passing_year = $_POST["passing_year"];
$Speciality = $_POST["speciality"];
$Title = $_POST["title"];
$Duration = $_POST["duration"];
$Present_add = $_POST["present_add"];
$Permanent_add = $_POST["permanent_add"];



$query="INSERT INTO `add_doc` (`id`,`fname`, `lname`, `email`, `password`, `mobile_no`, `country`, `gender`,`picture`, `certificate`, `institute`, `registration_no`, `roll_no`, `passing_year`, `speciality`, `title`, `duration`, `present_add`, `permanent_add`) VALUES ('".$id."','$Fname', '$Lname', '$Email', '$Password', '$Mobile_no', '$Country', '$Gender',
'$dbfile','$Certificate ', '$Institute', '$Registration_no', '$Roll_no', '$Passing_year ', '$Speciality', '$Title', '$Duration', '$Present_add', '$Permanent_add')";


$query2="INSERT INTO `users`(`UID`, `Email`, `Password`, `UserRole`, `Status`) VALUES ('".$id."','$Email','$Password','Doctor','Pending')";

//echo $query2;

if($con->query($query) === TRUE && $con->query($query2) === TRUE){
 echo "Success"; }
else
 {
    
echo $con->error;     
 }










//mysqli_query($con,$query);

//$Agree = $_POST["agree"];
//$Submit = $_POST["submit"];


//echo $Fname;
//echo "<br>";
//echo $Lname;
//echo "<br>";
//echo $Email;
//echo "<br>";
//echo $Password;
//echo "<br>";
//echo $Mobile_no;
//echo "<br>";
//echo $County;
//echo "<br>";
//echo $Gender;
//echo "<br>";
//echo $Certificate;
//echo "<br>";
//echo $Institute;
//echo "<br>";
//echo $Registration_no;
//echo "<br>";
//echo $Roll_no;
//echo "<br>";
//echo $Passing_year;
//echo "<br>";
//echo $Speciality;
//echo "<br>";
//echo $Title;
//echo "<br>";
//echo $Duration;
//echo "<br>";
//echo $Present_add;
//echo "<br>";
//echo $Present_add;
//echo "<br>";
//echo $Permanent_add;
//echo "<br>";
//echo $Submit;


?>
