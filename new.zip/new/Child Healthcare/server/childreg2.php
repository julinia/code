 <?php


require "../db/db.php";

$Fname = $_POST["fname"];
$Lname = $_POST["lname"];
$Age=$_POST["age"];
$Weight = $_POST["weight"];
$Gender = $_POST["gender"];
$Date = $_POST["date"];
$Fa_name = $_POST["fa_name"];
$Mo_name = $_POST["mo_name"];
$Address = $_POST["address"];
$Mobile_no = $_POST["mobile_no"];




$query="INSERT INTO `childreg2` (`fname`, `lname`,  `age`, `weight`, `gender`, `date`, `fa_name`, `mo_name`, `address`, `mobile`) VALUES ('$Fname', '$Lname',  '$Age', '$Weight', '$Gender', '$Date', '$Fa_name', '$Mo_name', '$Address', '$Mobile_no')";


if($con->query($query) === TRUE){
    echo "Success"; }
   else
    {
       
   echo $con->error;       
    }
   

?>