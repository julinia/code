<?php
require "../db/db.php";

$Fname = $_POST["name"];
$phone = $_POST["phone"];
$email=$_POST["email"];
$subject = $_POST["subject"];
$message = $_POST["message"];


echo $Fname;

$query="INSERT INTO `contact2` (`name`, `phone`, `email`, `subject`, `message`) VALUES ('$Fname', '$phone', '$email', '$subject', '$message')";


if($con->query($query) === TRUE){
    echo "Success"; }
   else
    {
       
   echo $con->error;       
    }
   

?>