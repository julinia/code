<?php

function idfinder($email){
        $usersql = "SELECT * FROM add_doc WHERE email = '".$email."'";
        
        include_once'../db/dbconnect.php';
        global $newdb;
        $res =  getDataFromDB($usersql);
        foreach($res as $row){
            return $row["id"];
        }

}

$Email = $_POST['email'];
$Password = md5($_POST['password']);

$usersql = "SELECT * FROM users WHERE Email = '".$Email."'";
include_once'../db/dbconnect.php';
$res =  getDataFromDB($usersql);
$count = count($res); 

if($count !=0) {
    session_start();
    foreach($res as $row){
        if($row['Email']==$Email and $row["Password"] == $Password ){

            if($row["UserRole"]=="Admin"){

                $_SESSION["UserRole"]='Admin';
                $_SESSION["Email"]=$row["Email"];
                $_SESSION['flag']='Running';

                header('Location:../admin/admin.php');
            }
            elseif($row["UserRole"]=="Doctor"){
                $_SESSION["UserRole"]='Doctor';
                $_SESSION["Email"]=$row["Email"];

                $_SESSION["doc_id"]= idfinder($row["Email"]);

                $_SESSION['flag']='Running';
                header('Location:../doctor/dashboard.php');
            }
            // elseif($row["UserRole"]=="Child"){
            //     $_SESSION["UserRole"]='Child';
            //     $_SESSION["Email"]=$row["Email"];
            //     $_SESSION['flag']='Running';
            //     header('Location:../doctor/dashboard.php');
            // }


            else {

                header('Location:../general/dashboard.php');
            }
        }
        else{
            echo "invalid  Uid and password";
        }
    }
}
else{
    echo "no user found";
}
?>
