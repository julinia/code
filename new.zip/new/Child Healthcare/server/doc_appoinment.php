<?php

require "../db/db.php";

$Pname = $_POST["pname"];
$Lname = $_POST["lname"];
$ID = $_POST["id"];
$Password = $_POST["password"];
$Age=$_POST["age"];
$Weight = $_POST["weight"];
$Date = $_POST["date"];
$Blood = $_POST["blood"];
$Mobile_no = $_POST["mobile_no"];
$Atime = $_POST["atime"];
$Dname = $_POST["dname"];
$Gender = $_POST["gender"];



// $query="INSERT INTO `doc_app2` (`pname`, `lname`, `id`, `password`, `age`, `weight`, `date`, `blood`, `mobile_no`, `atime`, `dname`, `gender`) VALUES ('$Pname', '$Lname', '$ID', '$Password', '$Age', '$Weight', '$Date', '$Blood', '$Mobile_no', '$Atime', '$Dname', '$Gender')";
$query="INSERT INTO `doc_appoinment` (`pname`, `lname`, `id`, `password`, `age`, `weight`, `date`, `blood`, `mobile_no`, `atime`, `dname`, `gender`) VALUES ('$Pname', '$Lname', '$ID', '$Password', '$Age', '$Weight', '$Date', '$Blood', '$Mobile_no', '$Atime', '$Dname', '$Gender')";



if($con->query($query) === TRUE){
    echo "Success"; }
   else
    {
       
   echo $con->error;       
    }
   

?>