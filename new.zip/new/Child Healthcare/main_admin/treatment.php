<!DOCTYPE html>
<html>
<head>

    <title>Treatment</title>
    <link rel="stylesheet" href="treatment.css">
</head>
<body>
  
   <div class="mytable">
       <div class="sign">
       <div class="main">
      
       <form action="treatment1.php" method="post">

          <table>

            <tr>
            <th colspan="2" class="form_header">Disease Definition</th>          
            </tr>

            <tr>
            <td>
            <label><b>Disease Id</b></label><br>
            <input type="text" name="Disease_id" placeholder="">            
            </td>
            </tr>
            <tr>
            <td>
            <label><b>Treatment</b></label><br>
            <input type="text" name="treatment" placeholder="">        
            </td>
            </tr>
             <div class="mytable2">
            <tr>
            <td colspan="2" class="submit_btn">
            <input type="submit" name="submit" value="Submit">
            </td>
            </tr>
            </div>

            </table>
      </form>
        </div>
     </div>
   </div> 
   
</body>
</html>