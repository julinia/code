<!DOCTYPE html>
<html>
<head>

    <title>Lifestyle</title>
    <link rel="stylesheet" href="lifestyle.css">
</head>
<body>
  
   <div class="mytable">
       <div class="sign">
       <div class="main">
      
       <form action="lifestyle1.php" method="post">

          <table>

            <tr>
            <th colspan="2" class="form_header">Disease Definition</th>          
            </tr>

            <tr>
            <td>
              <!--<label><b>Disease id</b></label><br>
           <input type="text" name="Disease_id" placeholder=""> -->
            <select name="Disease_id">
          <option>Disease Id</option>
          <?php
          $sql = "SELECT * FROM `disease_add`";
          include_once '../db/dbconnect.php';
          $result = getDataFromDB($sql);
          foreach($result as $row){
          ?>
          <option value="<?php echo $row["Disease_id"]; ?>"><?php echo $row["Disease_id"];?></option>
         <?php
          }
         ?>
         </select>


            </td>
            </tr>
            <td>
            <label><b>Lifestyle</b></label><br>
            <!-- <input type="text" name="lifestyle" placeholder="">         -->
            <textarea name="lifestyle" id="" cols="30" rows="10"></textarea>
            </td>
            </tr>
             <div class="mytable2">
            <tr>
            <td colspan="2" class="submit_btn">
            <input type="submit" name="submit" value="Submit">
            </td>
            </tr>
            </div>

            </table>
      </form>
        </div>
     </div>
   </div> 
   
</body>
</html>