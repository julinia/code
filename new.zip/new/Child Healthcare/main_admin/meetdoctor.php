<!DOCTYPE html>
<html>
<head>

    <title>meetdoctor</title>
    <link rel="stylesheet" href="meetdoctor.css">
</head>
<body>
  
   <div class="mytable">
       <div class="sign">
       <div class="main">
      
       <form action="meetdoctor.php" method="post">

          <table>

            <tr>
            <th colspan="2" class="form_header">When to see a doctor</th>          
            </tr>

            <tr>
            <td>
          <select name="Disease_id">
          <option>Disease Id</option>
          <?php
          $sql = "SELECT * FROM `disease_add`";
          include_once '../db/dbconnect.php';
          $result = getDataFromDB($sql);
          foreach($result as $row){
          ?>
          <option value="<?php echo $row["Disease_id"]; ?>"><?php echo $row["Disease_id"];?></option>
           <?php
          }
           ?>
         </select>
         </td>
         </tr>

            <tr>
            <td>
            <label><b>When to see a doctor</b></label><br>
            <textarea name="w_t_s_a_doctor" id="" cols="30" rows="10"></textarea>
            </td>
            </tr>


             <div class="mytable2">
            <tr>
            <td colspan="2" class="submit_btn">
            <input type="submit" name="submit" value="Submit">
            </td>
            </tr>
            </div>

            </table>
      </form>
        </div>
     </div>
   </div> 
   
</body>
</html>