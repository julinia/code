<!DOCTYPE html>
<html>
<head>

    <title>Doctor Appointment Form</title>
    <link rel="stylesheet" href="symptom.css">
</head>
<body>
  
   <div class="mytable">
       <div class="sign">
       <div class="main">
      
       <form action="symptom_add.php" method="post">

          <table>

            <tr>
            <th colspan="2" class="form_header">Disease</th>          
            </tr>

            <tr>
            <td>
            <label><b>Symptom ID</b></label><br>
            <input type="text" name="Symptom_id" placeholder="">            
            </td>
            </tr>
            <td>
            <label><b>Symptom Name</b></label><br>
            <input type="text" name=" Symptom_name" placeholder="">        
            </td>
            </tr>
             <div class="mytable2">
            <tr>
            <td colspan="2" class="submit_btn">
            <input type="submit" name="submit" value="Submit">
            </td>
            </tr>
            </div>

            </table>
      </form>
        </div>
     </div>
   </div> 
   
</body>
</html>