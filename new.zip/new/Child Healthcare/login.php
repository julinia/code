
<!DOCTYPE html>
<html>
<head>
	<title>Slide Navbar</title>
	<link rel="stylesheet" type="text/css" href="pannel/sty.css">
    
</head>
<body>
	   <div class="main">  	
			<div class="signup">
				<form action="server/login2.php" method="post">
					<label>WELCOME</label>
					<input type="email" name="email" placeholder="Email" required="">
					<input type="password" name="password" placeholder="Password" required="">
					<button>Log in</button>
				</form>
			</div>

			<div class="login"></div>
	 </div>

</body>
</html>







<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>login</title>
    <link rel="stylesheet" href="../pannel/sty.css">
</head>
<body>

   <div class="container">
       <div class="sign">
           <div class="header">
               <h1>WELCOME</h1>
               <P>Child Healthcare Development Society</P>
           </div>
           <div class="main">
               <form action="../server/login2.php" method="post">
                   <input type="email" name="email"  placeholder="Username">
                   <br>
                   <input type="password" name="password"  placeholder="Password">
                   <br>
                   <button>Login</button>
               </form>
           </div>
           <span>
               <ul>
                   <li><a href="admin/forgot.php">Forgot Password?</a></li><br>
                   <li><a href="admin/dashboard.php" target="blank">scrolling</a></li><br>

               </ul>
           </span>

       </div>
   </div> 
   
</body>
</html>

 -->
