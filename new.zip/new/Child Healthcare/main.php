
<div class="menu-bar">

           <div class="menu-bar1">
           <marquee behavior="" direction=""><h1><i> Welcome To Disease Detection System</i></h1></marquee>
          </div>
      <ul>

        <li><a href="../index.php">HOME</li>
        <li><a href="#">ABOUT US
        <div class="sub-menu-1">
            <ul>
                <li><a href="aboutus1.php">ABOUT US</a></li>
                <li><a href="aboutus2.php">MISSION</a></li>
              
            </ul>
        </div>
        </li>
        <li><a href="#">SERVICE
           <div class="sub-menu-1">
            <ul>
            <li><a href="process.php">PROCESS TO CHECK</a></li>
            <li><a href="../symptom_check/search.php">DISEASE CHECK</a></li>
            </ul>
           </div>
        </li>
        <li><a href="../appointment/appfpage.php">APPOINTMENT </a></li>

        <!-- <li><a href="#">OUR TEAM</li> -->
        <li><a href="#">REGISTRATION
        <div class="sub-menu-1">
            <ul>
                <li><a href="docreg.php">DOCTOR REGISTRATION</a></li>
                <!-- <li><a href="childreg.php">CHILDREN REGISTRATION</a></li>
                <li><a href="doc_app.php">DOCTOR APPOINTMENT</a></li> -->
            </ul>
        </div>

        
        </li>
        <li><a href="#">CONTACT
            <div class="sub-menu-1">
              <ul>
                <li><a href="contact.php">CONTACT US</a></li>
                <li><a href="reach.php">REACH US</a></li>
         
             </ul>
           </div>
         </li>
         <li><a href="../login.php">LOG IN</a></li>

   </ul>
</div>
