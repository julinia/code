<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Registration Form</title>
    <link rel="stylesheet" href="../pannel/childreg.css">
    <link rel="stylesheet" href="../common.css">
</head>
<body>


<div class="header">

<?php

include'../main.php';

?></div>
  
   <div class="mytable">
       <div class="sign">
       <form action="../server/childreg2.php" method="post">
          <table>
            <tr>
            <th colspan="2" class="form_header">CHILDREN REGISTREATION FORM</th>          
            </tr>
            <!-- <tr>
            <td colspan="2" class="section_header">
            <label><b>Personal Information</b></label>
            </td>
            </tr> -->
            <tr>
            <td style="margin-right: 10px;">
            <label>First Name</label><br>
            <input type="text" name="fname" placeholder="Enter your first name">            
            </td>
            <td>
            <label>Last Name</label><br>
            <input type="text" name="lname" placeholder="Enter your Last Name">
            </td>
            </tr>

             
            <tr>
            <td>
            <label>Age</label><br>
            <input type="number" name="age" placeholder="">            
            </td>
            <td>
              <label>Weight</label><br>
              <input type="number" name="weight" placeholder="">            
              </td>
            </tr>

            <tr>
            <td>
            <label>Gender</label><br>
            <input type="radio" name="gender" value="Male">
            <label>Male</label>&nbsp;
            <input type="radio" name="gender" value="Female">
            <label>Female</label>
            </td>

            <td>
           <label for=""><b>Date of Birth</b></label><br>
           <input type="date" name="date" id="">
           </td>

            </tr>

            <tr>
            <td style="margin-right: 10px;">
            <label>Father's Name</label><br>
            <input type="text" name="fa_name" placeholder="">            
            </td>
            <td>
            <label>Mother's Name</label><br>
            <input type="text" name="mo_name" placeholder="">
            </td>
            </tr>

            <tr>
            <td>
            <label>Email</label><br>
            <input type="email" name="email" placeholder="">            
            </td>
            <td>
              <label>Password</label><br>
              <input type="password" name="password" placeholder="">            
              </td>
            </tr>






            <tr>
              <td>
                <label>Address</label><br>
                <input type="address" name="address" placeholder="">
                </td>
                <td>
            <label>Mobile No</label><br>
            <input type="number" name="mobile_no" placeholder="">
            </td>
                </tr>
          
           <tr>
           <td colspan="2" class="submit_btn">
              <input type="submit" name="submit" value="Submit">
           </td>
           </tr>
           </table>
             </form>
     </div>
   </div> 
   
</body>
</html>