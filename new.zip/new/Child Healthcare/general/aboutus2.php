<!DOCTYPE html>
<html>
<head>
	<title>Aboutus</title>
	<link rel="stylesheet" type="text/css" href="aboutus2.css">
   <link rel="stylesheet" href="../common.css">
</head>
<body>
<div class="header">

<?php

include'../main.php';

?></div>
      <div class="container">
 
   <div class="content2">
      <h1><b>Primary care built around you</b></h1>    
      <p><b>We have built a healthcare system where you come first.
             Because nothing is more important than your child’s health.</b></p>
      
   </div>
   <div class="content2">
      <h1><b>Diagnostics you can trust</b></h1>    
      <p><b>Also able to give accurate results based on your information</b></p>
      
   </div>
   <div class="content2">
      <h1><b>Healthcare anytime, anywhere</b></h1>    
      <p><b>You can get the care you need 24/7 – be it online.
            </b></p>
      
   </div>		

   </div>
      
</body>
</html>