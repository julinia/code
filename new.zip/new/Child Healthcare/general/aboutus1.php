<!DOCTYPE html>
<html>
<head>
	<title>Aboutus</title>
	<link rel="stylesheet" type="text/css" href="aboutus1.css">
      <link rel="stylesheet" href="../common.css">

</head>
<body>

<div class="header">

<?php

include'../main.php';

?></div>


<div class="content">
      <h1><b>MEET CHILD HEALTHCARE DEVELOPMENT SOCIETY</b></h1>    
      <p><b>We believe that everyone should have access to convenient, affordable, and high-quality care. 
        We are on a mission to change how healthcare is delivered in Bangladesh. We know how daunting getting access to the right care can be which is why we focus on turning a doctor visit into a delightful experience
        Our goal is to make the process intuitive for our patients and provide care where ever you are in clinic or at-home.</b></p>
          
</div>		
</body>
</html>