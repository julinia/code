<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="team.css">
<style>

</style>
</head>
<body>
<div class="h1">
<h2>Responsive Image Gallery</h2>
</div>
<h4>Resize the browser window to see the effect.</h4>
<div class="way">
<div class="responsive">

  <div class="gallery">
    
      <img src="../picture/bhaiya.jpg" alt="Cinque Terre" width="600" height="400">
    </a>
    <div class="desc">Md Shakir Ahmed</div>
  </div>
</div>


<div class="responsive">
  <div class="gallery">
    
      <img src="../picture/bhaiya.jpg" alt="Forest" width="600" height="400">
    </a>
    <div class="desc">Add a description of the image here</div>
  </div>
</div>
</div>

<!-- <div class="responsive">
  <div class="gallery">
    
      <img src="../picture/bhaiya.jpg" alt="Northern Lights" width="600" height="400">
    </a>
    <div class="desc">Add a description of the image here</div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    
      <img src="../picture/bhaiya.jpg" alt="Mountains" width="600" height="400">
    </a>
    <div class="desc">Add a description of the image here</div>
  </div>
</div> -->

<div class="clearfix"></div>

<div style="padding:6px;">
  <p>This example use media queries to re-arrange the images on different screen sizes: for screens larger than 700px wide, it will show four images side by side, for screens smaller than 700px, it will show two images side by side. For screens smaller than 500px, the images will stack vertically (100%).</p>
  <p>You will learn more about media queries and responsive web design later in our CSS Tutorial.</p>
</div>

</body>
</html>


