<!DOCTYPE html>
<html>
<head>
	<title>Aboutus</title>
	<link rel="stylesheet" type="text/css" href="process.css">
   <link rel="stylesheet" href="../common.css">
   <script src="https://kit.fontawesome.com/ce8c39f0e8.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="header">

<?php

include'../main.php';

?></div>
      <div class="container">
 
   <div class="content2">
      <h1><b><i class="fa-solid fa-user-tie"></i> First Step</b></h1>    
      <p><b>First, select the symptoms from the checkbox that your child is ill.</b></p>
      
   </div>
   <div class="content2">
      <h1><b><i class="fa-solid fa-user-tie"></i> Second Step</b></h1>    
      <p><b>See the left side after selecting a symptom"Your symptom is saying that you might 
          be affected by any of the following one. For more specific result press submit"</b></p>
      
   </div>
   <div class="content2">
      <h1><b><i class="fa-solid fa-user-tie"></i> Third Step</b></h1>    
      <p><b>Some possible disease suggestions will be shown here according to your first provided symptom. If you are satisfied with the suggestion you can click on the disease name for the advice. For more specific suggestion provide another symptom you are facing and press submit.This procedure will be continued till your satisfaction and till you click on the disease name.
</b></p>
      
   </div>	
   
   <div class="content2">
      <h1><b><i class="fa-solid fa-user-tie"></i> Forth Step</b></h1>    
      <p><b>As our suggestions are showed depending on your provided symptoms. So select the symptoms carefully.</b></p>
      
   </div>

   <!-- <div class="content2">
      <h1><b>Fifth Step</b></h1>    
      <p><b>Lastly, this website will give you a possible solution</b></p>
      
   </div> -->

   </div>
      
</body>
</html>