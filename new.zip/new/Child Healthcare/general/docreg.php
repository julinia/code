<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Registration Form</title>
    <link rel="stylesheet" href="../pannel/docregis.css">
    <link rel="stylesheet" href="../common.css">
</head>
<body>

<div class="header">

<?php

include'../main.php';

?></div>
  
  
   <div class="mytable">   
       <form action="../server/add_doc.php" method="post" enctype="multipart/form-data">

          <div class="row">
            <div class="container nipa">
            <h1>Doctor REGISTREATION FORM</h1>

            <label><b>First Name</b></label><br>
            <input type="text" name="fname" placeholder="Enter your first name">  

            <label><b>Last Name</b></label><br>
            <input type="text" name="lname" placeholder="Enter your Last Name">

            <label><b>Email</b></label><br>
            <input type="email" name="email" placeholder=""> 
            
            <label><b>Password</b></label><br>
            <input type="password" name="password" placeholder=""> <br>
              
            <label><b>Mobile No</b></label><br>
            <input type="number" name="mobile_no" placeholder="">

            <label><b>Message</b></label><br>
            <textarea name="country" rows="5" placeholder="Your message"></textarea><br>

            <label><b>Gender</b></label>
            <input type="radio" name="gender" value="Male">
            <label><b>Male</b></label>&nbsp;
            <input type="radio" name="gender" value="Female">
            <label><b>Female</b></label><br>

            <label><b>Your picture</b></label><br>
            <input type="file" name="picture"><br>

            <label for=""> <b> Degree/Certificate</b></label><br>
            <input type="text" name="certificate" placeholder="Enter your qualification ">

            <!-- <label><b>Education Qualification</b></label>
            <input type="text" name="lname" placeholder="Enter your qualification "> -->

            <label for=""><b>Institute</b></label><br>
            <input type="text" name="institute" placeholder="Enter Institute">

            <label><b>Registration No</b></label><br>
            <input type="number" name="registration_no" placeholder="">

            <label><b>Roll No</b></label><br>
            <input type="number" name="roll_no" placeholder="">

            <label><b>Passing Year</b></label><br>
            <input type="date" name="passing_year" id="">

            <label><b>Speciality</b></label><br>
            <input type="text" name="speciality" placeholder="Enter Speciality">  
            
            <label><b>Title</b></label><br>
             <input type="text" name="title" placeholder="Enter Title">  

             <label><b>Experience Duration</b></label><br>
             <input type="text" name="duration" placeholder="Duration">

             <label><b>Present address</b></label><br>
             <input type="text" name="present_add" placeholder="">

             <label><b>Permanent address</b></label><br>
             <input type="text" name="permanent_add" placeholder="">

             <input type="checkbox" name="agree">
             <label for=""><b>I agreed with terms and conditions</b></label>

             <button type="submit" class="registerbtn">Submit</button>
            





            </div>
          </div>



                          <!-- <table>
                            <tr>
                            <th colspan="2" class="form_header">DOCTOR REGISTREATION FORM</th>          
                            </tr>
                            <tr>
                            <td colspan="2" class="section_header">
                            <label><b>Personal Information</b></label>
                            </td>
                            </tr>
                            <tr>
                            <td style="margin-right: 10px;">
                            <label>First Name</label><br>
                            <input type="text" name="fname" placeholder="Enter your first name">            
                            </td>
                            <td>
                            <label>Last Name</label><br>
                            <input type="text" name="lname" placeholder="Enter your Last Name">
                            </td>
                            </tr>

                            <tr>
                            <td>
                            <label>Email</label><br>
                            <input type="email" name="email" placeholder="">            
                            </td>
                            <td>
                              <label>Password</label><br>
                              <input type="password" name="password" placeholder="">            
                              </td>
                            </tr>
                            <tr>
                              <td>
                            <label>Mobile No</label><br>
                            <input type="number" name="mobile_no" placeholder="">
                            </td>

                            <td>
                            <label>Message</label><br>
                            <textarea name="country" rows="5" placeholder="Your message"></textarea>
                              
                            </td>
                            </tr>
                            <tr>
                            <td>
                            <label>Gender</label><br>
                            <input type="radio" name="gender" value="Male">
                            <label>Male</label>&nbsp;
                            <input type="radio" name="gender" value="Female">
                            <label>Female</label>
                            </td>
                            <td>
                            <label>Your picture</label><br>
                            <input type="file" name="picture">
                            </td>
                            </tr>
                            <tr>
                              <td colspan="2" class="section_header">
                              <label><b>Education</b></label>
                              </td>
                              </tr>
                          <tr>
                          <td>
                          <label for="">Degree/Certificate</label><br>
                          <select name="certificate" id="">
                            <option value="PHD">PHD</option>
                            <option value="MS">MBBS</option>
                            <option value="BS">PS</option>
                          </select>
                          </td>
                          <td>
                          <label for="">Institute</label><br>
                          <input type="text" name="institute" placeholder="Enter Institute">
                          </td>
                          </tr>
                          <tr>
                            <td>
                              <label>Registration No</label><br>
                              <input type="number" name="registration_no" placeholder="">
                              </td>
                              <td>
                                <label>Roll No</label><br>
                                <input type="number" name="roll_no" placeholder="">
                                </td>

                          </tr>
                          <tr>
                          <td>
                          <label for="">Passing Year</label><br>
                          <input type="date" name="passing_year" id="">
                          </td>
                          </tr>
                          <tr>
                          <td colspan="2" class="section_header">
                          <label for=""><b>Experience</b></label>
                          </td>
                          </tr>
                          <tr>
                            <td>
                              <label>Speciality</label><br>
                              <input type="text" name="speciality" placeholder="Enter Speciality">            
                            </td>
                          <td>
                            <label>Title</label><br>
                            <input type="text" name="title" placeholder="Enter Title">            
                          </td>
                        
                          </tr>
                          <tr>
                          <td>
                            <label>Experience Duration</label><br>
                            <input type="text" name="duration" placeholder="Duration">
                          </td>
                          </tr>
                          <tr>
                            <td colspan="2" class="section_header">
                            <label for=""><b>Address</b></label>
                            </td>
                            </tr>
                            <tr>
                              <td>
                                <label>Present address</label><br>
                                
                                <input type="address" name="present_add" placeholder="">
                              </td>
                                <td>
                                  <label>Permanent address</label><br>
                                  <input type="address" name="permanent_add" placeholder="">
                                  
                                </td>
                                </tr>
                          <tr>
                          <td colspan="2">
                            <input type="checkbox" name="agree">
                            <label for="">I agreed with terms and conditions</label>
                          </td>
                          </tr>
                          <tr>
                          <td colspan="2" class="submit_btn">
                              <input type="submit" name="submit" value="Submit">
                          </td>
                          </tr>
                          </table> -->
          </form>
             

   </div> 
   
</body>
</html>