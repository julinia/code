<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <link rel="stylesheet" href="../pannel/contact.css">
    <link rel="stylesheet" href="../common.css">
    <!-- <link rel="stylesheet" href="../kajkorbo/common.css"> -->
</head>
<body>

<div class="header">

<?php

include'../main.php';

?></div>
      <div class="container">
      <h1>Contact With Us</h1>
      <p>We would love to respond to your queries and help you succed. Feel Free to get in touch with us</p>
      <div class="contact-box">
        <div class="contact-left">
            <h3>Send Your Request</h3>
            <form action="../server/contact2.php" method="post">
                <div class="input-row">
                     <div class="input-group">
                          <label>Name</label><br>
                          <input type="text" name="name" placeholder="">
                     </div>
                     <div class="input-group">
                          <label>Phone</label><br>
                          <input type="text" name="phone" placeholder="">  
                     </div>
                </div>
                <div class="input-row">
                     <div class="input-group">
                          <label>Email</label><br>
                          <input type="email" name="email" placeholder="">
                     </div>
                     <div class="input-group">
                          <label>Subject</label><br>
                          <input type="text" name="subject" placeholder="">  
                     </div>
                </div>

                          <label>Message</label><br>
                          <textarea name="message" rows="5" placeholder="Your message"></textarea>
                         
                           <button type="submit">SEND</button>
        </div>
        <div class="contact-right">
        <!-- <h3>Reach us</h3> -->

        <!-- <table>
            <tr>
                <td>Email</td>
                <td>nahidaakternipa200419@gmail.com</td>
            </tr>

            <tr>
                <td>Phone</td>
                <td>01736033557</td>
            </tr>

            <tr>
                <td>Address</td>
                <td>Mirpur Dhaka</td>
            </tr>
        </table> -->
            
        </div>
        
      </div>
     </div>
</body>
</html>