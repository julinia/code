<!DOCTYPE html>
<html lang="en">
<head>
<!-- <link rel="stylesheet" href="../pannel/docregis.css"> -->
    <!-- <link rel="stylesheet" href="../kajkorbo/common.css"> -->
    <link rel="stylesheet" href="aboutus1.css">
    <!-- <link rel="stylesheet" href="aboutus2.css"> -->
    <link rel="stylesheet" href="../common.css">
    
    <title>Document</title>
</head>
<body>

<div class="header">

<?php

include'../main.php';

?></div>



<div class="container">

<?php

include'aboutus1.php';

?></div>

<div class="footer">

<?php

// include'aboutus2.php';

?></div>








    <?php
      // include'../main.php';
      ?>
      <?php
      // include'aboutus1.php';
      ?>
      <?php
    //   include'aboutus2.php';
      ?>
      <?php
      // include'aboutus.php';
      ?>

</body>
</html>