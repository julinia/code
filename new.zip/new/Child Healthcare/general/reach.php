<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="../common.css">
    <link rel="stylesheet" href="reach.css">
</head>
<body>
<div class="header">

    <div class="container">
    <h3>Reach us</h3>

       <table>
            <tr>
                <td>Email</td>
                <td>nahidaakternipa200419@gmail.com</td>
            </tr>
            <tr>
                <td>Phone</td>
                <td>01736033557</td>
            </tr>
            <tr>
                <td>Address</td>
                <td>Mirpur Dhaka</td>
            </tr>
         </table>
    </div>


    
</body>
</html> -->


<!DOCTYPE html>
<html>
<head>
	<title>Aboutus</title>
	<link rel="stylesheet" type="text/css" href="reach.css">
   <link rel="stylesheet" href="../common.css">
</head>
<body>
<div class="header">

<?php

include'../main.php';

?></div>

      <div class="container">
      <div class="content2">
        <h1><b>REACH US</b></h1>    
        <!-- <p><b>nahidaakternipa200419@gmail.com</b></p> -->
      
       </div>
      
     <div class="content2">
        <h1><b>Email</b></h1>    
        <p><b>nahidaakternipa200419@gmail.com</b></p>

       </div>
      <div class="content2">
        <h1><b>Phone</b></h1>    
       <p><b>01736033557</b></p>
      
      </div>
       <div class="content2">
        <h1><b>Address</b></h1>    
        <p><b>Mirpur Dhaka</b></p>
     
      </div>		

     </div>
      
</body>
</html>