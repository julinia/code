<?php

if ($_SESSION["userrole"] == "admin" AND $_SESSION["Flag"] =='Running'){

?>
<style>
    td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
    table{
        color: black;
        margin-top:25px;
        margin-left:25px;
    }
    h2{
        color: black;
    }
    /* .pic{
        height:200px ;
        width: 200px;

    } */
    td img{
        height: 60px;
        width: 60px;

    }
.col-12{
  
padding-left: 2%;
  width: 100%;
}

    #myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;}
#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
  

</style>
<?php

 
  $sql=" SELECT * FROM `users` WHERE Status = 'Pending'";
   
  require '../db/dbconnect.php';

  $container= getDataFromDB($sql);




  ?>
  <h2 align="center">Vehicles list</h2>
  <!-- <div class="col-12">
  <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search here...." title="Type in a name">
  </div> -->

  <table class="table table-sm"  width="95%">
      <tr>
          <th>Serial No</th>
          <th>Owner</th>
          <th>Address</th>
          <th>NID</th>
          <th>Vehicle Brand (Model)</th>
          <th>Reg No (Date)</th>
          <th>Color</th>
          <th>Number of Seat</th>
          <th>Driver</th>
          <th>Driver Address</th>
          <th>Action</th>
         
         



      </tr>

      <?php 
          foreach($container as $row){
      ?>

              <tr>
                  <td><?php echo $row["serialno"] ?></td>
                  <td><?php echo $row["firstName"].' '.$row["LastName"] ?></td>
                  <td><?php echo $row["Address"] ?></td>
                  <td><?php echo $row["NIDNO"] ?></td>
                  <td><?php echo $row["Vehiclesbrand"].' ('.$row["Model"].')' ?></td>
                  <td><?php echo $row["RegistrationNo"].' ('.$row["RegistrationDate"].')' ?></td>
                  <td><?php echo  $row["Color"] ?></td>
                  <td><?php echo $row["NumberofSeat"] ?></td>
                  <td><?php echo $row["fname"].' '.$row["lname"] ?></td>
                  <td><?php echo $row["Addres"] ?></td>
                  <td><a class="btn btn-sm btn-success" href="approvesingle.php?id=<?php echo $row["serialno"] ?>">Approve</a></td>








              </tr>

          <?php


          }
          ?>
  </table>
  
<?php
}
else{
  header("Location: ../signin.php");
}
 ?>