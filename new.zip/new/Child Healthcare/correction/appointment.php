<!DOCTYPE html>
<html>
<head>
<title>Child appointment</title>
<link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="childapp.css">
</head>
<body>

<form action="../server/child_app.php" method="post">

   <div class="row">
        <div class="container nipa ">
            <h1>CHILDREN REGISTREATION FORM</h1>
        

            <label> <b> First Name</b></label>
            <input type="text" name="fname" placeholder="">   


            <label><b>Last Name</b></label>
            <input type="text" name="lname" placeholder="">


            <label><b>Age</b></label>
            <input type="number" name="age" placeholder="">      


            <label><b>Weight</b></label>
            <input type="number" name="weight" placeholder="">  
            
            
            <label><b>Gender</b></label>
            <input type="radio" name="gender" value="Male">
            <label><b>Male</b></label>&nbsp;
            <input type="radio" name="gender" value="Female">
            <label><b>Female</b></label><br>


            <label for=""><b>Date of Birth</b></label>
            <input type="date" name="date" id="">


            <label><b>Father's Name</b></label>
            <input type="text" name="fa_name" placeholder="">    


            <label><b>Mother's Name</b></label>
            <input type="text" name="mo_name" placeholder="">

            <label><b>Email</b></label>
            <input type="email" name="email" placeholder="">  


            <label><b>Password</b></label>
            <input type="password" name="password" placeholder="">
            
            

            <label><b>Address</b></label>
            <input type="text" name="address" placeholder="">

            <label><b>Mobile No</b></label>
            <input type="text" name="mobile_no" placeholder="">


            <label><b>Patient problem</b></label>
            <input type="text" name="patient" placeholder="">


            <label><b>Appointment date</b></label>
            <input type="text" name="app_date" readonly placeholder=""  value="<?php echo $_GET['date']; ?>">



            <label><b>Doctor Id</b></label>
            <input type="text" name="doc_id" readonly value="<?php echo $_GET['doc_id']; ?>" placeholder="">


            <button type="submit" class="registerbtn">Submit</button>
        </div>
   </div>    
</form>

</body>
</html>
