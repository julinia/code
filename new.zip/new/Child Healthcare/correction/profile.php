<!DOCTYPE html>
<html lang="en">

<head>
    <title>Appointment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/ce8c39f0e8.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

    <script src="../jquery.js"></script>
    <link rel="stylesheet" href="fpage.css">
</head>

<body>

    <?php
    function vacationchecker($date,$id){
        include_once('../db/dbconnect.php');
        global $newdb;
        
        $sql = "SELECT * FROM vac_add WHERE doc_id = '".$id."' AND date = '".$date."'";
        $result = getDataFromDB($sql);
       $count = count($result);
        if($count == 0){
            return 'No';
        }
        else{
            return 'Yes';
        }
         } 
    
    function availabilitychecker($date,$id){
         include_once('../db/dbconnect.php');
        global $newdb;
        
        $sql = "SELECT * FROM app_counter WHERE Date = '".$date."' and DoctorID = '".$id."'";
        $result = getDataFromDB($sql);
        if($result != NULL){
            foreach ($result as $row){
                if($row["AppointmentLeft"] == 0){
                    return "Unavailable";
                }
                else{
                    return 'Available';
                }
            }
        }
        else{
            return 'Available';
        }
    }
    
    ?>

<div class="row bg">
     <div class="shadow" >
            <div class="menu-bar1" style=" background:gray;" >
                <marquee behavior="" direction=""><h1 style=" color:rgb(73, 6, 73);"><i> Welcome To Disease Detection System </i></h1></marquee>
            </div>
       
         <div class="container-fluid" style=" background:gray;">
            <nav class="navbar justify-content-center navbar-light  ">

               <ul class="nav nav-pills" role="tablist">

              
                <li class="nav-item ">
                <a class="nav-link text-light" href="../index.php">HOME</a>
               </li>
          

               <!-- <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa-solid fa-house-chimney"> HOME</i>
                HOME
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="#">Link 1</a>
                    <a class="dropdown-item " href="#">Link 2</a>
                    <a class="dropdown-item " href="#">Link 3</a>
                </div>
                </li> -->


                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">ABOUT US</a>

                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/aboutus1.php">ABOUT US</a>
                    <a class="dropdown-item " href="../general/aboutus2.php">MISSION</a>
                   
                </div>
                </li>

                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">SERVICE</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/process.php">PROCESS TO CHECK</a>
                    <a class="dropdown-item " href="../symptom_check/search.php">DISEASE CHECK</a>
                   
                </div>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light" href="appfpage.php">APPOINTMENT</a>
                </li>

                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">REGISTRATION</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/docreg.php">DOCTOR REGISTRATION</a>
                    <!-- <a class="dropdown-item " href="../general/childreg.php">CHILDREN REGISTRATION</a>
                    <a class="dropdown-item " href="../general/doc_app.php">DOCTOR APPOINTMENT</a> -->
                   
                </div>

                </li> 
                
                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">CONTACT</a>

                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/contact.php">CONTACT US</a>
                    <a class="dropdown-item " href="../general/reach.php">REACH US</a>
                   
                   
                </div>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light" href="../login.php">LOG IN</a>
                </li>
                </ul>
          </nav>
          </div>




            <div class="container-fluid p-5">
                <div class="row">
                    <?php 
                            include_once ('../db/dbconnect.php');
                      
                      $fetchsql = "SELECT * FROM `add_doc` WHERE id = '".$_GET['id']."' ";
                      $result = getDataFromDB($fetchsql);
                      
                      foreach($result as $row){
                          ?>
                    <div class="col-6 p-5">
                        <div class="card m-auto" style="width:400px">
                            <img class="card-img-top" src="../<?php echo $row['picture'] ?>" alt="Card image">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo $row['fname'].' '.$row['lname'] ?></h4>
                                <p class="card-text"><?php echo $row['speciality'] ?> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 p-5">
                        <h3 style=" color:rgb(73, 6, 73);">Schedule</h3>
                        <p style=" color:rgb(73, 6, 73);"> <b><?php echo $row['country'] ?> </b> </p>
                        <table style="width:100%">
                            <tr>
                                <th>Date</th>
                                <th>Timing</th>
                                <th>Status</th>
                                <th>Appointment</th>
                            </tr>
                            <tr>


                                <td  class="p-3"><?php echo date("Y/m/d"); ?></td>
                                <?php 
                          $res = vacationchecker(date("Y/m/d"),$_GET['id']);
                          if($res == 'Yes'){
                              
                              ?>
                              <td class="p-3"><span class="text-danger">Today is off Day</span></td>
                              <td class="p-3"></td>
                              <td class="p-3"></td>
                              <?php 
                              
                          }
                          else{
                              ?>
                              <td class="p-3">07.00 pm to 10.00 pm</td>
                              <td><?php
                          
                          echo availabilitychecker(date("Y/m/d"),$_GET['id']) ;?></td>
                             
                                <td class="p-3"><?php if(availabilitychecker(date("Y/m/d"),$_GET['id']) == "Avaiable"){
                              ?>
                              <a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm btn-success">Make an appointment</a>
                              <?php
                          } ?>
                             </td>
                              <?php 
                             
                          }
                           ?>
                                
                            </tr>
                             
                             
                             
                             
                              <tr>
                                <td><?php
                             $stop_date = new DateTime(date('Y/m/d'));

                            $stop_date->modify('+1 day');
                            $datenew = $stop_date->format('Y/m/d');
                          
                          echo $datenew; ?></td>
                                <?php 
                       
                          $res = vacationchecker($datenew,$_GET['id']);
                          if($res == 'Yes'){
                              
                              ?>
                              <td class="p-3"><span class="text-danger">Today is off Day</span></td>
                              <td class="p-3"></td>
                              <td class="p-3"></td>
                              <?php 
                              
                          }
                          else{
                              ?>
                              <td>07.00 pm to 10.00 pm</td>
                              <td><?php
                          
                          echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                             
                                <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm btn-success">Make an appointment</a></td>
                              <?php 
                             
                          }
                           ?>
                            </tr>           
                             
                             
                             
                              <tr>
                                <td><?php
                             $stop_date = new DateTime(date('Y/m/d'));

                            $stop_date->modify('+2 day');
                            $datenew = $stop_date->format('Y/m/d');
                          
                          echo $datenew; ?></td>
                                <?php 
                       
                          $res = vacationchecker($datenew,$_GET['id']);
                          if($res == 'Yes'){
                              
                              ?>
                              <td><span class="text-danger">Today is off Day</span></td>
                              <td></td>
                              <td></td>
                              <?php 
                              
                          }
                          else{
                              ?>
                              <td>07.00 pm to 10.00 pm</td>
                              <td><?php
                          
                          echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                             
                                <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm btn-success">Make an appointment</a></td>
                              <?php 
                             
                          }
                           ?>
                            </tr>           
                             
                             
                             
                              <tr>
                                <td><?php
                             $stop_date = new DateTime(date('Y/m/d'));

                            $stop_date->modify('+3 day');
                            $datenew = $stop_date->format('Y/m/d');
                          
                          echo $datenew; ?></td>
                                <?php 
                       
                          if($res == 'Yes'){
                              
                              ?>
                              <td><span class="text-danger">Today is off Day</span></td>
                              <td></td>
                              <td></td>
                              <?php 
                              
                          }
                          else{
                              ?>
                              <td>07.00 pm to 10.00 pm</td>
                              <td><?php
                          
                          echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                             
                                <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm btn-success">Make an appointment</a></td>
                              <?php 
                             
                          }
                           ?>
                            </tr>           
                             
                             
                             
                              <tr>
                                <td><?php
                             $stop_date = new DateTime(date('Y/m/d'));

                            $stop_date->modify('+4 day');
                            $datenew = $stop_date->format('Y/m/d');
                          
                          echo $datenew; ?></td>
                                <?php 
                       
                          $res = vacationchecker($datenew,$_GET['id']);
                         if($res == 'Yes'){
                              
                              ?>
                              <td><span class="text-danger">Today is off Day</span></td>
                              <td></td>
                              <td></td>
                              <?php 
                              
                          }
                          else{
                              ?>
                              <td>07.00 pm to 10.00 pm</td>
                              <td><?php
                          
                          echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                             
                                <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm btn-success">Make an appointment</a></td>
                              <?php 
                             
                          }
                           ?>
                            </tr>           
                             
                             
                             
                              <tr>
                                <td><?php
                             $stop_date = new DateTime(date('Y/m/d'));

                            $stop_date->modify('+5 day');
                            $datenew = $stop_date->format('Y/m/d');
                          
                          echo $datenew; ?></td>
                                <?php 
                       
                          $res = vacationchecker($datenew,$_GET['id']);
                          if($res == 'Yes'){
                              
                              ?>
                              <td><span class="text-danger">Today is off Day</span></td>
                              <td></td>
                              <td></td>
                              <?php 
                              
                          }
                          else{
                              ?>
                              <td>07.00 pm to 10.00 pm</td>
                              <td><?php
                          
                          echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                             
                                <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm btn-success">Make an appointment</a></td>
                              <?php 
                             
                          }
                           ?>
                            </tr>           
                             
                             
                             
                              <tr>
                                <td><?php
                             $stop_date = new DateTime(date('Y/m/d'));

                            $stop_date->modify('+6 day');
                            $datenew = $stop_date->format('Y/m/d');
                          
                          echo $datenew; ?></td>
                               <?php 
                       
                          $res = vacationchecker($datenew,$_GET['id']);
                          if($res == 'Yes'){
                              
                              ?>
                              <td><span class="text-danger">Today is off Day</span></td>
                              <td></td>
                              <td></td>
                              <?php 
                              
                          }
                          else{
                              ?>
                              <td>07.00 pm to 10.00 pm</td>
                              <td><?php
                          
                          echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                             
                                <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm btn-success">Make an appointment</a></td>
                              <?php 
                             
                          }
                           ?>
                            </tr>    
                             
                     
                        </table>
                        
                    </div>

                    <?php
                      }
                      ?>


                </div>
            </div>

            <div class="cantainer-fluid p-5">
                <h2 class="text-center">More Doctors</h2>
                <div id="demo" class="carousel slide" data-ride="carousel">

                    <!-- Indicators -->
                    <ul class="carousel-indicators">

                    </ul>

                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="card-columns">
                                <?php
                                        include_once('../db/dbconnect.php');
                                        $sql = "SELECT * FROM add_doc ORDER BY serial_no desc limit 3";
                                        $result = getDataFromDB($sql);
                                        foreach($result as $row){
                                  ?>
                                  <div class="card ml-5" style="width:300px; height: 400px; border: 4px solid rgb(73, 6, 73);">
                                        <img class="card-img-top" src="../<?php echo $row['picture'] ?>" alt="Card image" 
                                        style="width:100%; height: 200px;">
                                        <div class="card-body">
                                            <h4 class="card-title"><?php echo $row['fname'].' '.$row['lname'] ?></h4>
                                            <p class="card-text"><?php echo $row['speciality'] ?></p>
                                            <a href="profile.php?id=<?php echo $row["id"] ?>" class="btn">See Profile</a>
                                        </div>
                                 </div>
                                <?php 
                                  }
                                ?>
                            </div>

                        </div>
                        <div class="carousel-item ">
                            <div class="card-columns">
                                <?php
                            include_once('../db/dbconnect.php');
                               $sql = "SELECT * FROM add_doc ORDER BY serial_no asc limit 3";
                               $result = getDataFromDB($sql);
                               foreach($result as $row){
                                  ?>
                                <div class="card ml-5" style="width:300px; height: 400px; border: 4px solid rgb(73, 6, 73);">
                                    <img class="card-img-top" src="../<?php echo $row['picture'] ?>" alt="Card image" 
                                    style="width:100%; height: 200px;">
                                    <div class="card-body">
                                        <h4 class="card-title"><?php echo $row['fname'].' '.$row['lname'] ?></h4>
                                        <p class="card-text"><?php echo $row['speciality'] ?></p>
                                        <a href="profile.php?id=<?php echo $row["id"] ?>" class="btn">See Profile</a>
                                    </div>
                                </div>
                                <?php 
                               }
                            ?>


                            </div>

                        </div>

                    </div>

                    <!-- Left and right controls -->
                    <a class="carousel-control-prev" href="#demo" data-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </a>
                    <a class="carousel-control-next" href="#demo" data-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </a>

                </div>
            </div>

        </div>

    </div>
</body>

</html>
