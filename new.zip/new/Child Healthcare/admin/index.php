<!DOCTYPE html>
<html lang="en">
<head>
<!-- <link rel="stylesheet" href="../pannel/docregis.css"> -->
    <link rel="stylesheet" href="../pannel/common.css">
    <link rel="stylesheet" href="../common.css">
    <link rel="stylesheet" href="../pannel/adminnav.css">
  

    <title>Document</title>
</head>
<body>


<div class="header">

<?php

include'../main.php';

?></div>


  <div class="nope">
    <?php
      // include'sidebar.php';
      // include'maiin.php';
      
    ?>

    </div>
    <div class="nope2">

    </div>
</body>
</html>


<!--<!DOCTYPE html>
<html >
  <head>
    <title></title>
    <link rel="stylesheet" href="dashboard.css">
  </head>
  <body>
    <div class="master-body">
      <div class="sidebar">
          <div class="imagebar">
                <div class="imagebox">
                    <img src="" alt="">
                </div>
          </div>
        <div class="nav">
            <ul>
              <li>Home</li>
              <li>Account</li>
              <li>NID</li>
              <li>Result</li>
            </ul>
        </div>
      </div>
      <div class="main">
        <div class="navbar">
            <div class="searchbar">
                <input type="text" name="" value="">
                <button type="button" name="button">Search</button>
            </div>

            <div class="second-nav">
                  <ul>
                    <li><a href="#">Profile</a></li>
                    <li><a href="#">Register</a></li>
                    <li><a href="#">Log Out</a></li>

                  </ul>
            </div>

        </div>
      </div>
    </div>
  </body>
</html>-->
