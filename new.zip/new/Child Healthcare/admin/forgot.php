
<!DOCTYPE html>
<html>
<head>

    <title>Document</title>
    <link rel="stylesheet" href="../pannel/forgot.css">
</head>
<body>
    <div class="forgot">
        <div class="pass">
            <form action="">
               <h3>Reset Your password</h3>
               <p><h6>We will email you instruction to reset the password</h6></p>
               <div class="int">

                <input type="email" name="email" id="email" required placeholder="Email"><br>
               
                <input type="passwrd" name="password" placeholder=" reset password"><br>
           
              <input type="submit" value="submit" class="submit-btn">
        
            </form>


        </div>
    </div>
</body>
</html>
