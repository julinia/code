
<div class="sidebar">
    <div class="imagebar">
        <div class="imagebox">
            <img src="" alt="">

        </div>

    </div>
    <div class="nav">
    <ul>
              <li> <a href="#">Home </a></li>


              <!-- <li> <a href="#">Home </a>
                 <ul>
                  <li> <a href="../main_admin/disease.php">disease</a> </li>
                  <li> <a href="../main_admin/symptom.php">symptom</a> </li>
                  <li> <a href="../view_data/disease_add2.php">disease_add2</a> </li>
                  <li> <a href="doc_app.php">Appointment</a> </li>
                 </ul>
              </li> -->
              <li> <a href="../main_admin/disease.php" target="blank">Disease Add</a></li>
              <li><a href="../main_admin/symptom.php" target="blank">Symptom Add</a></li>
              <li><a href="../view_data/disease_add2.php" target="blank">Disease</a></li>
              <li><a href="../view_data/symptom_add2.php" target="blank">Symptom</a></li>
              <li><a href="login.php" target="blank">Log in</a></li>

            </ul>

    </div>
</div>



<!--*{
    margin: 0px;
    padding: 0px;
    box-sizing: border-box;
  }
  .master-body{
    height: 100vh;
    margin: 0px;
  }
  
  .master-body .sidebar{
      width: 15%;
      height: 100vh;
      background: black;
      float: left;
  }
  
  
  .master-body .sidebar .imagebar{
      width: 100%;
      height: 150px;
  
      padding-top: 25px;
  }
  
  .master-body .sidebar .imagebar .imagebox{
      width: 100px;
      height: 100px;
      margin: auto;
      border-radius: 50%;
      background: red;
  }
  
  .master-body .sidebar .nav{
    color: white;
  
  }
  
  
  .master-body .sidebar .nav ul{
  
  
  }
  
  .master-body .sidebar .nav ul li{
    padding: 5px;
    font-size: 16px;
  
  }
  
  .master-body .sidebar .nav ul li:hover{
    background: blue;
  
  }
  
  
  .master-body .main{
      width: 85%;
      height: 100vh;
      float: left;
  }
  
  .master-body .main .navbar{
    height: 60px;
    background: gray;
    width: 100%;
  }
  
  .master-body .main .navbar .searchbar{
        height: 60px;
        width: 40%;
        padding: 10px 10px;
        float: left;
  }
  
  .master-body .main .navbar .searchbar input{
        padding: 10px;
        width: 60%;
        border-radius: 10px;
  
  }
  
  
  .master-body .main .navbar .searchbar button{
        padding: 10px;
        width: 20%;
        border-radius: 10px;
  
  }
  
  .master-body .main .navbar .searchbar button:hover{
        background: red;
  }
  
  .master-body .main .navbar .searchbar button:focus{
        background: blue;
  }
  
  
  .master-body .main .navbar .second-nav{
        height: 60px;
        width: 25%;
        float: right;
  }
  
  .master-body .main .navbar .second-nav ul{
  
  }
  .master-body .main .navbar .second-nav ul li{
   display: inline-block;
   width: 30%;
   line-height: 60px;
  
  }
  
  .master-body .main .navbar .second-nav ul li a{
    color: white;
    text-decoration: none;
    font-size: 20px;
    font-weight: bold;
  }-->
  

