<div class="menu-bar">
      <ul>

        <li><a href="#">home</li>
        <li><a href="#">ABOUT US
        <div class="sub-menu-1">
            <ul>
                <li><a href="general/aboutus.php">About Us</a></li>
                <li><a href="admin/childreg.php">MISSION</a></li>
                <li><a href="#">mission</a></li>
            </ul>
        </div>
        </li>
        <li><a href="#">SERVICE
           <div class="sub-menu-1">
            <ul>
            <li><a href="symptom_check/search.php">Disease check</a></li>
            </li>
                <li class="hover-me"><a href="#">marker</a>
                <div class="sub-menu-2">
                  <ul>
                    <li><a href="#">seo</a></li>
                    <li><a href="#">marteki</a></li>
                    <li><a href="#">go</a></li>
                  </ul>
                </div>
            </li>
             <li class="hover-me"><a href="#">mobile</a>
                <div class="sub-menu-2">
                <ul>
                   <li><a href="#">seo</a></li>
                   <li><a href="#">marteki</a></li>
                   <li><a href="#">go</a></li>
                   <li><a href="#">marteki</a></li>
               </ul>
        </div>
            </li>
            </ul>
        </div>
        </li>
        <li><a href="#">CLIENTS</li>
        <li><a href="#">REGISTRATION
        <div class="sub-menu-1">
            <ul>
                <li><a href="">DOCTOR REGISTRATION</a></li>
                <li><a href="admin/childreg.php">CHILDREN REGISTRATION</a></li>
                <li><a href="#">DOCTOR APPOINTMENT</a></li>
            </ul>
        </div>


        </li>
        <li><a href="#">CONTACT
            <div class="sub-menu-1">
              <ul>
                <li><a href="#">CONTACT US</a></li>
                <li><a href="#">REACH US</a>

             </ul>
           </div>
         </li>
         <li><a href="admin/login.php">LOG IN</li>

   </ul>
</div>
