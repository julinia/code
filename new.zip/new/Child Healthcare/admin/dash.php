
<!DOCTYPE html>
<html lang="en">
<head>
<!-- <link rel="stylesheet" href="../pannel/docregis.css"> -->
<title>Document</title>
    <link rel="stylesheet" href="../kajkorbo/common.css">
    


</head>
<body>
    <?php
      include'../kajkorbo/main.php';
      include'admin.php';
      
      
    ?>
</body>
</html>
