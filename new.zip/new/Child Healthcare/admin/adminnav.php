<?php
  // session_start();
  // if($_SESSION["UserRole"] == "Admin" AND $_SESSION["flag"] == "Running" ){

  


?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- <link rel="stylesheet" href="../pannel/docregis.css"> -->
    <link rel="stylesheet" href="../pannel/common.css">
    <link rel="stylesheet" href="../common.css">
  

    <title>Document</title>
</head>
<body>


<div class="header">

<?php

include'../main.php';

?></div>


  <div class="nope">
    <?php
      // include'sidebar.php';
      include'maiin.php';
      
    ?>

    </div>
    <div class="nope2">

    </div>
</body>
</html>
  <?php
  // }
  // else{
  //       echo '<script language="javascript">';
  //       echo 'alert("Invalid Login"); location.href="../login.php"';
  //       echo '</script>';
  // }
  ?>