<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="common.css">

    <title>Document</title>
</head>
<body>   

<div class="menu-bar">
<marquee behavior="" direction=""><h1><i> Society </i></h1></marquee>
   <ul>
       
        <li class="active"><a href="#">home</li>
        <!-- <li><a href="#">home</li> -->
        <li><a href="#">ABOUT US
        <div class="sub-menu-1">
            <ul>
                <li><a href="general/aboutus.php">About Us</a></li>
                <li><a href="#">mission</a></li>
                <li><a href="#">mission</a></li>
            </ul>
        </div>

        </li>
        <li><a href="#">services
        <div class="sub-menu-1">
            <ul>
            <li><a href="#">web</a></li>
                <!-- <li class="hover-me"><a href="#">web</a>
                <div class="sub-menu-2">
            <ul>
                <li><a href="#">mission</a></li>
                <li><a href="#">mission</a></li>
                <li><a href="#">mission</a></li>
            </ul>
        </div> -->

            </li>
                <li class="hover-me"><a href="#">marker</a>
                <div class="sub-menu-2">
            <ul>
                <li><a href="#">seo</a></li>
                <li><a href="#">marteki</a></li>
                <li><a href="#">go</a></li>
            </ul>
        </div>

            </li>
                <li class="hover-me"><a href="#">mobile</a>
                <div class="sub-menu-2">
            <ul>
                <li><a href="#">seo</a></li>
                <li><a href="#">marteki</a></li>
                <li><a href="#">go</a></li>
                <li><a href="#">marteki</a></li>
                
            </ul>
        </div>
            
            
            </li>
            </ul>
        </div>
        </li>
        <li><a href="#">clients</li>
        <li><a href="#">Registreation</li>
        <li><a href="#"> contact
        <div class="sub-menu-1">
            <ul>
                <li><a href="#">mission</a></li>
                <li><a href="#">mission</a>
                <div class="sub-menu-2">
            <ul>
                <li><a href="#">mission</a></li>
                <li><a href="#">mission</a></li>
                <li><a href="#">mission</a></li>
            </ul>
        </div>
            </li>
                <li><a href="#">mission</a></li>
            </ul>
        </div>
        </li>
       
   </ul> 
</div>

</body>
</html>