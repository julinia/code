<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <link rel="stylesheet" href="../common.css">
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
    *{
      box-sizing: border-box;
      margin: 0px;
      padding: 0px;
    }
    .header{
       height: 18vh;
       width:100%;
     }

     .container{

      height:82vh;
      width:100%;
     }
      .row{
        display: flex;
        width: 100%;
        justify-content: space-between;
      }
      .col-6{
        height: 800px;
        width: 50%;
        border: 4px solid black;
        padding: 20px;
        text-align: center;

      }
      .col-6 select{
        padding: 5px;
        width: 50%;
      }
      .col-6 p{
        font-size: 30px;
        margin-bottom: 10px;
        /* text-align: center; */

        color: rgb(73, 6, 73);
        
      }
      #result{
        text-align: left;
        padding-left: 30px;
      }

      .col-6 h3{
        margin-bottom: 10px;
        /* text-align: center; */
        font-size: 30px;


        color: rgb(73, 6, 73);
        
      }



    </style>
  </head>
  <body>
  <div class="header">

<?php

include'main.php';

?></div>
  
    <div class="container">
        <div class="row">
            <div class="col-6">
              <form class="" action="second.php" method="post">


              <p>
              Select a syntom the patient is facing?
              </p>
              <select class="" name="symptom1" id="symptom1" onchange="showDisease(this.value)">
                  <option value="">Select a symptom</option>
                    <?php
                      $sql = "SELECT * FROM symptom_add";
                      include_once '../db/dbconnect.php';
                      $symptom_result = getDataFromDB($sql);

                      foreach($symptom_result as $row){
                        ?>
                        <option value="<?php echo $row["Symptom_id"]; ?>"><?php echo $row["Serial_no"].'-'.$row["Symptom_name"]; ?></option>
                        <?php
                      }

                       ?>
                  </select>

                   <p style="margin-top: 20px"><button type="submit" name="button">Submit</button> 
                   <button type="reset" value="Reset">Reset</button> 
                    <!-- <button> <a href="search.php"> back to home </a></button></p> -->
                   </form>
            </div>

            <div class="col-6">

                <h3 id="result">
                  Your Result will be shown here...
                </h3>
            </div>

        </div>
    </div>
  </body>
  <script>


  function showDisease(str){
    if(str == ""){
      document.getElementById('result').innerHTML = "Please select secondary symptom";
      return ;
    }
    var xhttp;
    xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status == 200){
        document.getElementById('result').innerHTML = this.responseText;
      }
    };

    xhttp.open('GET', 'singlecheck.php?Symptom1='+str, true);
    xhttp.send();

  }
  </script>

</html>
