<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <link rel="stylesheet" href="../common.css">
    <meta charset="utf-8">
    <title></title>
    <?php

      SESSION_START();
      function syname($id){
          $sql = "SELECT Symptom_name FROM symptom_add WHERE Symptom_id = '".$id."'";
          include_once '../db/dbconnect.php';
          $symptom_result = getDataFromDB($sql);
          foreach ($symptom_result as $key) {
            return $key["Symptom_name"];
          }
      }
      function disname($id){
          $sql = "SELECT Disease_name FROM disease_add WHERE Disease_id = '".$id."'";
          include_once '../db/dbconnect.php';
          $symptom_result = getDataFromDB($sql);
          foreach ($symptom_result as $key) {
            return $key["Disease_name"];
          }
      }

      ?>
    <style media="screen">
    *{
      box-sizing: border-box;
      margin: 0px;
      padding: 0px;
    }
    .header{
       height: 18vh;
       width:100%;
     }

     .container{

      height:82vh;
      width:100%;
     }
     .row{
        display: flex;
        width: 100%;
        justify-content: space-between;
      }
      .col-6{
        height: 800px;
        width: 50%;
        border: 4px solid black;
        padding: 20px;
        text-align: center;
      }
      .col-6 select{
        padding: 5px;
        width: 50%;
      }
      .col-6 p{
        font-size: 30px;
        margin-bottom: 10px;
        /* text-align: center; */

        color: rgb(73, 6, 73);
        
      }
      #result{
        text-align: left;
        padding-left: 30px;
      }

      .col-6 h3{
        margin-bottom: 10px;
        /* text-align: center; */
        font-size: 30px;


        color: rgb(73, 6, 73);
        
      }


    </style>
  </head>
  <body>

  <div class="header">

<?php

include'main.php';

?></div>

    <?php
    $sym = $_POST["symptom1"];
    $sql = "SELECT * FROM disease_add WHERE Symptom1 = '".$sym."' OR  Symptom2 = '".$sym."' OR  Symptom3 = '".$sym."' OR  Symptom4 = '".$sym."' OR  Symptom5 = '".$sym."' OR  Symptom6 = '".$sym."' OR  Symptom7 = '".$sym."' OR  Symptom8 = '".$sym."' OR Symptom9 = '".$sym."'";
    include_once '../db/dbconnect.php';

    $d1_result = getDataFromDB ($sql);
    $z = 0;

    $count = count($_SESSION["Disease"]);
    $disease1 = array();
    $disease2 = array();

        foreach ($d1_result as $row) {
          for($i=0; $i<$count; $i++){
            if ($row["Disease_id"] == $_SESSION["Disease"][$i]) {

              array_push($disease1,$row["Disease_id"]);
              array_push($disease2,disname($row["Disease_id"]));
              // $z++;
            }
          }
        }

      $_SESSION['Disease'] = $disease1;
      $_SESSION['DiseaseName'] = $disease2;
      // var_dump($_SESSION["Disease"]);
     ?>

    <div class="container">
        <div class="row">
            <div class="col-6">
              <form class="" action="sixth.php" method="post">

              <p id="title">
              Select a syntom the patient is facing?
             </p>
              <select class="" name="symptom1" id="symptom1" onchange="showDisease(this.value)">
                  <option value="">Select a symptom</option>
                    <?php
                      $sql = "SELECT * FROM symptom_add";
                      include_once '../db/dbconnect.php';
                      $symptom_result = getDataFromDB($sql);

                      foreach($symptom_result as $row){
                        ?>
                        <option value="<?php echo $row["Symptom_id"]; ?>"><?php echo $row["Serial_no"].'-'.$row["Symptom_name"]; ?></option>
                        <?php
                      }

                       ?>
            </select>

            <p style="margin-top: 20px"><button type="submit" name="button">Submit</button> 
               <button type="reset" value="Reset">Reset</button></p>
              </form>


              <?php

              array_push ($_SESSION["SymptomList"],$_POST['symptom1'] );
              array_push ($_SESSION["SymptomNameList"],syname($_POST['symptom1']) );

               ?>
               <div style="width: 40%; float: left">
                 <h3>Your submitted symptoms.</h3>
                 <ol>
                   <?php
                     $countlist = count($_SESSION["SymptomNameList"]);
                     for($i = 0; $i<$countlist; $i++){
                       ?>
                         <li><?php echo $_SESSION["SymptomNameList"][$i]; ?></li>
                       <?php
                     }
                    ?>
                 </ol>
               </div>
               <div style="width: 20%; height: 20vh; float: left">
               </div>
               <div style="width: 40%; float: left">
               <h3>Your previous result: <span id="session"><?php echo count($_SESSION["DiseaseName"]) ?></span> Diseases matched</h3>
                 <ol>
                   <?php
                     $countlist = count($_SESSION['DiseaseName']);
                     for($i = 0; $i<$countlist; $i++){
                       ?>
                         <li> <a href="advice.php?diseaseid=<?php echo $_SESSION['Disease'][$i]; ?>"> <?php echo $_SESSION['DiseaseName'][$i]; ?></a> </li>

                       <?php
                     }
                    ?>
                 </ol>
               </div>




            </div>

            <div class="col-6">

                <h3 id="result">


                </h3>
            </div>

        </div>
    </div>
  </body>
  <script>


  function showDisease(str){
    if(str == ""){
      document.getElementById('result').innerHTML = "Please select secondary symptom";
      return ;
    }
    var xhttp;
    xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status == 200){
        // document.getElementById('phpresult').innerHTML = '';
        document.getElementById('result').innerHTML = this.responseText;
      }
    };

    xhttp.open('GET', 'doublecheck.php?Symptom1='+str, true);
    xhttp.send();

  }
  </script>

</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
    var count = document.getElementById("session").innerHTML;
    
    if(count < 2){
      $(document).ready(function(){
      $("#title").hide();
      $("#symptom1").hide();
      $("button").hide();
    });
    }
  </script>
