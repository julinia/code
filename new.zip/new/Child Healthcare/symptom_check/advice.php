<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <link rel="stylesheet" href="../common.css">
    <meta charset="utf-8">
    <title></title>


<style media="screen">
  *{
      box-sizing: border-box;
      margin: 0px;
      padding: 0px;
    }
    .header{
       height: 18vh;
       width:100%;
     }

     .container{

      height:82vh;
      width:100%;
     }
  h1{
    color: rgb(73, 6, 73);
    border-bottom: 2px solid rgb(73, 6, 73);
  }
  img{
    height: 400px;
    width: 400px;
  }
</style>

<body>
  <div class="header">

<?php

include'main.php';

?></div>
  
    <div class="container">


<h1>Definition</h1>


<?php
$sql = "SELECT * FROM definition1 WHERE Disease_id = '".$_GET["diseaseid"]."'";
include_once '../db/dbconnect.php';

$def = getDataFromDB($sql);
foreach($def as $row){
  echo $row['disease_definition'];
}


 ?>


<h1>Symptom</h1>
<ol>

<?php
$sql = "SELECT * FROM disease_add WHERE Disease_id = '".$_GET["diseaseid"]."'";
include_once '../db/dbconnect.php';
  function symptomname ($id){
    $sql= "SELECT * FROM symptom_add WHERE Symptom_id= '".$id."'";
    include_once '../db/dbconnect.php';
    $def = getDataFromDB($sql);
    foreach($def as $row){
      return $row['Symptom_name'];
    }


  }
$def = getDataFromDB($sql);
foreach($def as $row){
?>
<li style='margin-left: 25px;'><?php echo symptomname($row['Symptom1'])?></li>
<li style='margin-left: 25px;'><?php echo symptomname($row['Symptom2'])?></li>
<li style='margin-left: 25px;'><?php echo symptomname($row['Symptom3'])?></li>
<li style='margin-left: 25px;'><?php echo symptomname($row['Symptom4'])?></li>
<li style='margin-left: 25px;'><?php echo symptomname($row['Symptom5'])?></li>
<li style='margin-left: 25px;'><?php echo symptomname($row['Symptom6'])?></li>
<li style='margin-left: 25px;'><?php echo symptomname($row['Symptom7'])?></li>

<?php
}


 ?>
</ol>

 <h1>When to check up?</h1>


 <?php


 $sql = "SELECT * FROM `meetdoctor1` WHERE Disease_id = '".$_GET["diseaseid"]."'";
 include_once '../db/dbconnect.php';

 $def = getDataFromDB($sql);
 foreach($def as $row){
   echo $row['meetdoctor'];
 }



  ?>

 <h1>Test</h1>


 <?php
 $sql = "SELECT * FROM test1  WHERE Disease_id = '".$_GET["diseaseid"]."'";
 include_once '../db/dbconnect.php';

 $def = getDataFromDB($sql);
 foreach($def as $row){
   echo $row['test'];
 }



  ?>

 <h1>Treatment</h1>


 <?php
 $sql = "SELECT * FROM treatment1  WHERE Disease_id = '".$_GET["diseaseid"]."'";
 include_once '../db/dbconnect.php';

 $def = getDataFromDB($sql);
 foreach($def as $row){
   echo $row['treatment'];
 }



  ?>

 <h1>Lifestyle</h1>


 <?php
 $sql = "SELECT * FROM lifestyle1  WHERE Disease_id = '".$_GET["diseaseid"]."'";
 include_once '../db/dbconnect.php';

 $def = getDataFromDB($sql);
 foreach($def as $row){
   echo $row['lifestyle'];
 }



  ?>

 <h1>Pictures</h1>


 <?php
 $sql = "SELECT * FROM picture_add  WHERE Disease_id = '".$_GET["diseaseid"]."'";
 include_once '../db/dbconnect.php';

 $def = getDataFromDB($sql);
 foreach($def as $row){
   ?>
      <img src="../diseasse_picture/<?php echo $row["picture1"]; ?>" alt="">
      <img src="../diseasse_picture/<?php echo $row["picture2"]; ?>" alt="">

   <?php
 }



  ?>

</div>
</body>
</html>
  
