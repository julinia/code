<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <link rel="stylesheet" href="../common.css">
    <meta charset="utf-8">
    <title></title>
    <?php

      SESSION_START();
      function syname($id){
          $sql = "SELECT Symptom_name FROM symptom_add WHERE Symptom_id = '".$id."'";
          include_once '../db/dbconnect.php';
          $symptom_result = getDataFromDB($sql);
          foreach ($symptom_result as $key) {
            return $key["Symptom_name"];
          }
      }
      function disname($id){
          $sql = "SELECT Disease_name FROM disease_add WHERE Disease_id = '".$id."'";
          include_once '../db/dbconnect.php';
          $symptom_result = getDataFromDB($sql);
          foreach ($symptom_result as $key) {
            return $key["Disease_name"];
          }
      }?>
    <style media="screen">
    *{
      box-sizing: border-box;
      margin: 0px;
      padding: 0px;
    }
    .header{
       height: 18vh;
       width:100%;
     }

     .container{

      height:82vh;
      width:100%;
     }
     .row{
        display: flex;
        width: 100%;
        justify-content: space-between;
      }
      .col-6{
        height: 800px;
        width: 50%;
        border: 4px solid black;
        padding: 20px;
        text-align: center;
      }
      .col-6 select{
        padding: 5px;
        width: 50%;
      }
      .col-6 p{
        font-size: 30px;
        margin-bottom: 10px;
        text-align: center;

        color: rgb(73, 6, 73);
      }

      .col-6 h3{
        margin-bottom: 10px;
        text-align: center;
        font-size: 30px;


        color: rgb(73, 6, 73);
        
      }
    </style>
  </head>
  <body>

  <div class="header">

<?php

include'main.php';

?></div>

    <?php
    $sym = $_POST["symptom1"];
    $sql = "SELECT * FROM disease_add WHERE Symptom1 = '".$sym."' OR  Symptom2 = '".$sym."' OR  Symptom3 = '".$sym."' OR  Symptom4 = '".$sym."' OR  Symptom5 = '".$sym."' OR  Symptom6 = '".$sym."' OR  Symptom7 = '".$sym."' OR  Symptom8 = '".$sym."' OR Symptom9 = '".$sym."'";
    include_once '../db/dbconnect.php';

    $d1_result = getDataFromDB ($sql);
    $z = 0;

    $count = count($_SESSION["Disease"]);
    $disease1 = array();

        foreach ($d1_result as $row) {
          for($i=0; $i<$count; $i++){
            if ($row["Disease_id"] == $_SESSION["Disease"][$i]) {

              array_push($disease1,$row["Disease_id"]);
              // $z++;
            }
          }
        }

      $_SESSION['Disease'] = $disease1;
      // var_dump($_SESSION["Disease"]);
     ?>

    <div class="container">
        <div class="row">
            <div class="col-6">


              <?php

                            array_push ($_SESSION["SymptomList"],$_POST['symptom1'] );
               ?>
               <div style="width: 40%; float: left">
                 <h3>Your submitted symptoms.</h3>
                 <ol>
                   <?php
                     $countlist = count($_SESSION["SymptomNameList"]);
                     for($i = 0; $i<$countlist; $i++){
                       ?>
                         <li><?php echo $_SESSION["SymptomNameList"][$i]; ?></li>
                       <?php
                     }
                    ?>
                 </ol>
               </div>
               <div style="width: 20%; height: 20vh; float: left">
               </div>
               <div style="width: 40%; float: left">
                 <h3>Your previous result.</h3>
                 <ol>
                   <?php
                     $countlist = count($_SESSION['DiseaseName']);
                     for($i = 0; $i<$countlist; $i++){
                       ?>
                         <li> <a href="advice.php?diseaseid=<?php echo $_SESSION['Disease'][$i]; ?>"> <?php echo $_SESSION['DiseaseName'][$i]; ?></a> </li>

                       <?php
                     }
                    ?>
                 </ol>
               </div>



            </div>

            <div class="col-6">

              <h3>You may affected by </h3>
              <ol>
                <?php
                  $countlist = count($_SESSION['Disease']);
                  for($i = 0; $i<$countlist; $i++){
                    ?>
                      <li><a href="advice.php?diseaseid=<?php echo $_SESSION['Disease'][$i]; ?>"> <?php echo disname($_SESSION['Disease'][$i]); ?></a></li>
                    <?php
                  }
                 ?>
              </ol>
            </div>

        </div>
    </div>
  </body>

</html>
