
<style>

   a{ 
     text-decoration: none;
     color: black;
     padding-left: 20px;

   }
</style>
<?php




function firstdisease($sym){

  $sql = "SELECT * FROM disease_add WHERE Symptom1 = '".$sym."' OR  Symptom2 = '".$sym."' OR  Symptom3 = '".$sym."' OR  Symptom4 = '".$sym."' OR  Symptom5 = '".$sym."' OR  Symptom6 = '".$sym."' OR  Symptom7 = '".$sym."' OR  Symptom8 = '".$sym."' OR Symptom9 = '".$sym."'";
  include_once '../db/dbconnect.php';
  $disease1 = array();
  $diseaseid = array();
  $d1_result = getDataFromDB ($sql);
    ?>

      <?php
          foreach ($d1_result as $row) {

          array_push($disease1, $row["Disease_name"]);
          array_push($diseaseid, $row["Disease_id"]);
          }
          SESSION_START();
          $_SESSION['DiseaseName'] = $disease1;
          $_SESSION['Disease'] = $diseaseid;
          ?>
          <h3 style="padding-left: 20%; padding-right: 20%; padding-bottom: 30px;">Your symptom is saying that you might be affected by any of the following one. For more specific result press submit</h3>
          <ol>

              <?php
                $countdisease =  count($disease1);
                if($countdisease != 0){
                  for($i=0; $i<$countdisease; $i++){
                  ?>
                  <li> <a href="advice.php?diseaseid=<?php echo $diseaseid[$i]; ?>"> <?php echo $disease1[$i]; ?></a> </li>
                  <?php
                  }
                }
               ?>
          </ol>

        <?php


}

firstdisease($_GET["Symptom1"]);
 ?>
