<?php
SESSION_START();

function firstdisease($sym){

  $sql = "SELECT * FROM disease_add WHERE Symptom1 = '".$sym."' OR  Symptom2 = '".$sym."' OR  Symptom3 = '".$sym."' OR  Symptom4 = '".$sym."' OR  Symptom5 = '".$sym."' OR  Symptom6 = '".$sym."' OR  Symptom7 = '".$sym."' OR  Symptom8 = '".$sym."' OR Symptom9 = '".$sym."'";

  include_once '../db/dbconnect.php';
  $disease1 = array();
  $diseaseid = array();
  $d1_result = getDataFromDB ($sql);
    // $z = 0;?>

      <?php
      $count = count($_SESSION["Disease"]);
// echo $count;

          foreach ($d1_result as $row) {
              for($i=0; $i<$count; $i++){
                if ($row["Disease_id"] == $_SESSION["Disease"][$i]) {
                  array_push($disease1, $row["Disease_name"]);
                  array_push($diseaseid, $row["Disease_id"]);
                  // array_push($diseaseid, $row["Disease_id"]);
                }
              }


          }
            // var_dump($_SESSION["Disease"]);
          ?>

              <?php
                $countdisease =  count($disease1);
                if($countdisease != 0){
                  ?>
                  <h3 style="padding-left: 20%; padding-right: 20%; padding-bottom: 30px;">Your symptom is saying that you might be affected by any of the following one. For more specific result press submit</h3>
                  <ul>
                  <?php
                  for($i=0; $i<$countdisease; $i++){
                  ?>
                  <li> <a href="advice.php?diseaseid=<?php echo $diseaseid[$i]; ?>"> <?php echo $disease1[$i]; ?></a> </li>
                  <?php
                  }
                  ?>

                  </ul>

                  <?php
                }
                else{
                  
                  ?>
                    <h3>We are sorry that no matching found. You can check the previous details.</h3>
                  <?php

                $sessioncount = count($_SESSION["Disease"]);
                for($i=0; $i<$sessioncount; $i++){
                  ?>
                  <li> <a href="advice.php?diseaseid=<?php echo $_SESSION["Disease"][$i]; ?>"> <?php echo $_SESSION["DiseaseName"][$i]; ?></a> </li>
                  <?php

                }
                }
               ?>


        <?php


}

firstdisease($_GET["Symptom1"]);
 ?>
