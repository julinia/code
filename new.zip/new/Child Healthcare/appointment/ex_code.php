<!--
                              <tr>
                                <td><?php
                             $stop_date = new DateTime(date('Y/m/d'));

                             $stop_date->modify('+2 day');
                             $datenew = $stop_date->format('Y/m/d');
                           
                           echo $datenew; ?></td>
                                 <?php 
                        
                           $res = vacationchecker($datenew,$_GET['id']);
                           if($res == 'Yes'){
                               
                               ?>
                               <td><span class="text-danger">Today is off Day</span></td>
                               <td></td>
                               <td></td>
                               <?php 
                               
                           }
                           else{
                               ?>
                               <td>07.00 pm to 10.00 pm</td>
                               <td><?php
                           
                           echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                              
                                 <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm ">Make an appointment</a></td>
                               <?php 
                              
                           }
                            ?>
                             </tr>           
                              
                              
                              
                               <tr>
                                 <td><?php
                              $stop_date = new DateTime(date('Y/m/d'));
 
                             $stop_date->modify('+3 day');
                             $datenew = $stop_date->format('Y/m/d');
                           
                           echo $datenew; ?></td>
                                 <?php 
                        
                           if($res == 'Yes'){
                               
                               ?>
                               <td><span class="text-danger">Today is off Day</span></td>
                               <td></td>
                               <td></td>
                               <?php 
                               
                           }
                           else{
                               ?>
                               <td>07.00 pm to 10.00 pm</td>
                               <td><?php
                           
                           echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                              
                                 <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm ">Make an appointment</a></td>
                               <?php 
                              
                           }
                            ?>
                             </tr>           
                              
                              
                              
                               <tr>
                                 <td><?php
                              $stop_date = new DateTime(date('Y/m/d'));
 
                             $stop_date->modify('+4 day');
                             $datenew = $stop_date->format('Y/m/d');
                           
                           echo $datenew; ?></td>
                                 <?php 
                        
                           $res = vacationchecker($datenew,$_GET['id']);
                          if($res == 'Yes'){
                               
                               ?>
                               <td><span class="text-danger">Today is off Day</span></td>
                               <td></td>
                               <td></td>
                               <?php 
                               
                           }
                           else{
                               ?>
                               <td>07.00 pm to 10.00 pm</td>
                               <td><?php
                           
                           echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                              
                                 <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm ">Make an appointment</a></td>
                               <?php 
                              
                           }
                            ?>
                             </tr>           
                              
                              
                              
                               <tr>
                                 <td><?php
                              $stop_date = new DateTime(date('Y/m/d'));
 
                             $stop_date->modify('+5 day');
                             $datenew = $stop_date->format('Y/m/d');
                           
                           echo $datenew; ?></td>
                                 <?php 
                        
                           $res = vacationchecker($datenew,$_GET['id']);
                           if($res == 'Yes'){
                               
                               ?>
                               <td><span class="text-danger">Today is off Day</span></td>
                               <td></td>
                               <td></td>
                               <?php 
                               
                           }
                           else{
                               ?>
                               <td>07.00 pm to 10.00 pm</td>
                               <td><?php
                           
                           echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                              
                                 <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm ">Make an appointment</a></td>
                               <?php 
                              
                           }
                            ?>
                             </tr>           
                              
                              
                              
                               <tr>
                                 <td><?php
                              $stop_date = new DateTime(date('Y/m/d'));
 
                             $stop_date->modify('+6 day');
                             $datenew = $stop_date->format('Y/m/d');
                           
                           echo $datenew; ?></td>
                                <?php 
                        
                           $res = vacationchecker($datenew,$_GET['id']);
                           if($res == 'Yes'){
                               
                               ?>
                               <td><span class="text-danger">Today is off Day</span></td>
                               <td></td>
                               <td></td>
                               <?php 
                               
                           }
                           else{
                               ?>
                               <td>07.00 pm to 10.00 pm</td>
                               <td><?php
                           
                           echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                              
                                 <td><a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm ">Make an appointment</a></td>
                               <?php 
                              
                           }
                            ?>
                             </tr>    
 300 line theke shuru-->