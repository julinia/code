<!DOCTYPE html>
<html>
<head>
<title>Child appointment</title>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://kit.fontawesome.com/ce8c39f0e8.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="childapp.css">
<link rel="stylesheet" href="fpage.css">
<style>
      .nav-pills .nav-link.active{
          background: unset;
      }
      .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
    color: #fff;
    background-color: unset;
}
      .dropdown-menu.show {
    display: block;
    background: gray;
          color: white;
}
      .dropdown-item{
          color: white;
      }
      .dropdown-item:hover {
   background: unset;
}
    </style>
</head>
<body>

    
<div class="row bg">
     <div class="shadow" >
            <div class="menu-bar1" style=" background:gray;" >
                <marquee behavior="" direction=""><h1 style=" color:rgb(73, 6, 73);"><i> Welcome To Disease Detection System </i></h1></marquee>
            </div>
       
         <div class="container-fluid" style=" background:gray;">
            <nav class="navbar justify-content-center navbar-light  ">

               <ul class="nav nav-pills" role="tablist">

              
                <li class="nav-item ">
                <a class="nav-link text-light" href="../index.php">HOME</a>
               </li>
          

               <!-- <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa-solid fa-house-chimney"> HOME</i>
                HOME
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="#">Link 1</a>
                    <a class="dropdown-item " href="#">Link 2</a>
                    <a class="dropdown-item " href="#">Link 3</a>
                </div>
                </li> -->


                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">ABOUT US</a>

                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/aboutus1.php">ABOUT US</a>
                    <a class="dropdown-item " href="../general/aboutus2.php">MISSION</a>
                   
                </div>
                </li>

                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">SERVICE</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/process.php">PROCESS TO CHECK</a>
                    <a class="dropdown-item " href="../symptom_check/search.php">DISEASE CHECK</a>
                   
                </div>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light"  href="appfpage.php">APPOINTMENT</a>
                </li>

                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">REGISTRATION</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/docreg.php">DOCTOR REGISTRATION</a>
                    <!-- <a class="dropdown-item " href="../general/childreg.php">CHILDREN REGISTRATION</a>
                    <a class="dropdown-item " href="../general/doc_app.php">DOCTOR APPOINTMENT</a> -->
                   
                </div>

                </li> 
                
                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">CONTACT</a>

                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/contact.php">CONTACT US</a>
                    <a class="dropdown-item " href="../general/reach.php">REACH US</a>
                   
                   
                </div>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light" href="../login.php">LOG IN</a>
                </li>
                </ul>
          </nav>
          </div>



<form action="../server/child_app.php" method="post">

   <div class="row">
        <div class="container nipa ">
            <h1>CHILDREN REGISTREATION FORM</h1>
        

            <label> <b> First Name</b></label>
            <input type="text" name="fname" placeholder="">   


            <label><b>Last Name</b></label>
            <input type="text" name="lname" placeholder="">


            <label><b>Age</b></label>
            <input type="number" name="age" placeholder="">      


            <label><b>Weight</b></label>
            <input type="number" name="weight" placeholder="">  
            
            
            <label><b>Gender</b></label>
            <input type="radio" name="gender" value="Male">
            <label><b>Male</b></label>&nbsp;
            <input type="radio" name="gender" value="Female">
            <label><b>Female</b></label><br>


            <label for=""><b>Date of Birth</b></label>
            <input type="date" name="date" id="">


            <label><b>Father's Name</b></label>
            <input type="text" name="fa_name" placeholder="">    


            <label><b>Mother's Name</b></label>
            <input type="text" name="mo_name" placeholder="">

            <label><b>Email</b></label>
            <input type="email" name="email" placeholder="">  

            <label><b>Address</b></label>
            <input type="text" name="address" placeholder="">

            <label><b>Mobile No</b></label>
            <input type="text" name="mobile_no" placeholder="">


            <label><b>Patient problem</b></label>
            <input type="text" name="patient" placeholder="">


            <label><b>Appointment date</b></label>
            <input type="text" name="app_date" readonly placeholder=""  value="<?php echo $_GET['date']; ?>">



            <label><b>Doctor Id</b></label>
            <input type="text" name="doc_id" readonly value="<?php echo $_GET['doc_id']; ?>" placeholder="">

            <button type="submit" class="registerbtn">Submit</button>
        
            
        </div>
   </div>    
</form>

</body>
</html>
