<!DOCTYPE html>
<html lang="en">

<head>
    <title>Appointment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- lobstarfonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lobster+Two&display=swap" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/ce8c39f0e8.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

    <script src="../jquery.js"></script>
    <link rel="stylesheet" href="fpage.css">
    <!-- cpoy kit -->
    <script src="https://kit.fontawesome.com/ce8c39f0e8.js" crossorigin="anonymous"></script>
    <style>
      .btn{
    border:  1px solid rgb(73, 6, 73);
    outline:  1px solid rgb(73, 6, 73);   
    }
     .btn:hover{
    background: rgb(73, 6, 73);
    color: white;
    }



    .nav-pills .nav-link.active{
          background: unset;
      }
      .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
    color: #fff;
    background-color: unset;
}
      .dropdown-menu.show {
    display: block;
    background: gray;
          color: white;
}
      .dropdown-item{
          color: white;
      }
      .dropdown-item:hover {
   background: unset;
}

th{
    font-size:30px;
    color:rgb(73, 6, 73);
}


    </style>

  
</head>

<body>

    <?php
    function vacationchecker($date,$id){
        include_once('../db/dbconnect.php');
        global $newdb;
        
        $sql = "SELECT * FROM vac_add WHERE doc_id = '".$id."' AND date = '".$date."'";
        $result = getDataFromDB($sql);
        $count = count($result);
        if($count == 0){
            return 'No';
        }
        else{
            return 'Yes';
        }
         } 
    
        function availabilitychecker($date,$id){
        include_once('../db/dbconnect.php');
        global $newdb;
        
        $sql = "SELECT * FROM app_counter WHERE Date = '".$date."' and DoctorID = '".$id."'";
        $result = getDataFromDB($sql);
        if($result != NULL){
            foreach ($result as $row){
                if($row["AppointmentLeft"] == 0){
                    return "Unavailable";
                }
                else{
                    return 'Available';
                }
            }
        }
        else{
            return 'Available';
        }
    }
    
    ?>
<div class="row bg">
     <div class="shadow" >
            <div class="menu-bar1" style=" background:gray;" >
                <marquee behavior="" direction=""><h1 style=" color:rgb(73, 6, 73);"><i> Welcome To Disease Detection System </i></h1></marquee>
            </div>
       
         <div class="container-fluid" style=" background:gray;">
            <nav class="navbar justify-content-center navbar-light  ">

               <ul class="nav nav-pills" role="tablist">

              
                <li class="nav-item ">
                <a class="nav-link text-light" href="../index.php">HOME</a>
               </li>
          

               <!-- <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa-solid fa-house-chimney"> HOME</i>
                HOME
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="#">Link 1</a>
                    <a class="dropdown-item " href="#">Link 2</a>
                    <a class="dropdown-item " href="#">Link 3</a>
                </div>
                </li> -->


                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">ABOUT US</a>

                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/aboutus1.php">ABOUT US</a>
                    <a class="dropdown-item " href="../general/aboutus2.php">MISSION</a>
                   
                </div>
                </li>

                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">SERVICE</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/process.php">PROCESS TO CHECK</a>
                    <a class="dropdown-item " href="../symptom_check/search.php">DISEASE CHECK</a>
                   
                </div>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light" href="appfpage.php">APPOINTMENT</a>
                </li>

                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">REGISTRATION</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/docreg.php">DOCTOR REGISTRATION</a>
                    <!-- <a class="dropdown-item " href="../general/childreg.php">CHILDREN REGISTRATION</a>
                    <a class="dropdown-item " href="../general/doc_app.php">DOCTOR APPOINTMENT</a> -->
                   
                </div>

                </li> 
                
                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">CONTACT</a>

                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/contact.php">CONTACT US</a>
                    <a class="dropdown-item " href="../general/reach.php">REACH US</a>
                   
                   
                </div>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light" href="../login.php">LOG IN</a>
                </li>
                </ul>
              </nav>
          </div>



            <div class="container-fluid p-5">
                <div class="row">
                    <?php 
                        include_once ('../db/dbconnect.php');
                      
                      $fetchsql = "SELECT * FROM `add_doc` WHERE id = '".$_GET['id']."' ";
                      $result = getDataFromDB($fetchsql);
                      
                      foreach($result as $row){
                          ?>
                    <div class="col-6 p-5">
                        <div class="card m-auto" style="width:400px">
                            <img class="card-img-top" src="../<?php echo $row['picture'] ?>" alt="Card image">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo $row['fname'].' '.$row['lname'] ?></h4>
                                <p class="card-text"><?php echo $row['speciality'] ?> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 p-5">
                        <h3 style=" color:rgb(73, 6, 73);"><i class="fa-solid fa-calendar-days"></i>Schedule</h3>
                        <p style=" color:rgb(73, 6, 73); font-size: 20px;"> <b><?php echo $row['country'] ?> </b> </p>
                        <table class="table table-striped table-bordered" style="width:100%">
                            <tr>
                                <th><i class="fa-solid fa-calendar"></i> Date</th>
                                <th><i class="fa-solid fa-business-time"></i> Timing</th>
                                <th><i class="fa-solid fa-signal"></i> Status</th>
                                <th><i class="fa-solid fa-briefcase-medical"></i> Appointment</th>
                            </tr>

                            <tr>
                                <td  class="p-3"><?php echo date("Y/m/d"); ?></td>
                                <?php 
                                    $res = vacationchecker(date("Y/m/d"),$_GET['id']);
                                    if($res == 'Yes'){
                               ?>
                              <td class="p-3"><span class="text-danger">Today is off Day</span></td>
                              <td class="p-3"></td>
                              <td class="p-3"></td>
                              <?php 
                              
                          } else{
                              ?>
                              <td>07.00 pm to 10.00 pm</td>
                              <td><?php                        
                                  echo availabilitychecker(date("Y/m/d"),$_GET['id']) ;?></td>                             
                               <td>
                                
                                <?php
                                    if(availabilitychecker(date("Y/m/d"),$_GET['id']) == 'Available'){
                                        ?>
                                         <a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo date("Y/m/d")?>" class="btn btn-sm ">Make an appointment</a>
                                        <?php
                                    }
                              else{  
                             }
                                    ?>                               
                                </td>
                              <?php 
                             
                          }
                           ?>
                                
                            </tr>
                                                                                       
                              <tr>
                                <td><?php
                             $stop_date = new DateTime(date('Y/m/d'));

                            $stop_date->modify('+1 day');
                            $datenew = $stop_date->format('Y/m/d');                         
                                  echo $datenew; ?></td>
                                <?php                       
                          $res = vacationchecker($datenew,$_GET['id']);
                          if($res == 'Yes'){                             
                              ?>
                              <td class="p-3"><span class="text-danger">Today is off Day</span></td>
                              <td class="p-3"></td>
                              <td class="p-3"></td>
                              <?php 
                              
                          }
                          else{
                              ?>
                              <td>07.00 pm to 10.00 pm</td>
                              <td><?php
                          
                          echo availabilitychecker($datenew,$_GET['id']) ;?></td>
                             
                              <td>
                                
                                <?php
                                    if(availabilitychecker($datenew,$_GET['id']) == 'Available'){
                                        ?>
                                         <a href="appointment.php?doc_id=<?php echo $row["id"] ?>&date=<?php echo $datenew?>" class="btn btn-sm ">Make an appointment</a>
                                        <?php
                                    }
                              else{
                                  
                              }
                                    ?>
                               
                                
                                </td>
                              <?php 
                             
                          }
                           ?>
                            </tr>           
                             
                             

                             
                     
                        </table>
                        
                    </div>

                    <?php
                      }
                      ?>


                </div>
            </div>

            <div class="cantainer-fluid" style=" padding-left: 80px; margin-top: 50px;">
            <h1 class="ml-5" style=" border-bottom: 2px solid rgb(73, 6, 73); color: rgb(73, 6, 73);"><i class="fa-solid fa-user-doctor"></i>OUR SPECIAL DOCTOR IS HERE</h2> 
                <div id="demo" class="carousel slide" data-ride="carousel" style=" padding-left: 80px; margin-top: 50px;">

                    <!-- Indicators -->
                    <ul class="carousel-indicators">

                    </ul>

                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="card-columns">
                                <?php
                                        include_once('../db/dbconnect.php');
                                        // $sql = "SELECT * FROM add_doc ORDER BY serial_no desc limit 3";
                                        $sql = "SELECT * FROM add_doc inner join users on users.UID = add_doc.id WHERE status='Approved' ORDER BY serial_no desc limit 3";
                                        $result = getDataFromDB($sql);
                                        foreach($result as $row){
                                  ?>
                                  <div class="card " style="width:300px; height: 400px; border: 4px solid rgb(73, 6, 73); margin-left: 90px;">
                                        <img class="card-img-top" src="../<?php echo $row['picture'] ?>" alt="Card image" 
                                        style="width:100%; height: 200px;">
                                        <div class="card-body">
                                            <h4 class="card-title"><?php echo $row['fname'].' '.$row['lname'] ?></h4>
                                            <p class="card-text"><?php echo $row['speciality'] ?></p>
                                            <a href="profile.php?id=<?php echo $row["id"] ?>" class="btn">See Profile</a>
                                        </div>
                                 </div>
                                <?php 
                                  }
                                ?>
                            </div>

                        </div>
                        <div class="carousel-item ">
                            <div class="card-columns">
                                <?php
                            include_once('../db/dbconnect.php');
                            //    $sql = "SELECT * FROM add_doc ORDER BY serial_no asc limit 3";
                               $sql = "SELECT * FROM add_doc inner join users on users.UID = add_doc.id WHERE status='Approved' ORDER BY serial_no asc limit 3";
                               $result = getDataFromDB($sql);
                               foreach($result as $row){
                                  ?>
                                <div class="card " style="width:300px; height: 400px; border: 4px solid rgb(73, 6, 73); margin-left: 90px;">
                                    <img class="card-img-top" src="../<?php echo $row['picture'] ?>" alt="Card image" 
                                    style="width:100%; height: 200px;">
                                    <div class="card-body">
                                        <h4 class="card-title"><?php echo $row['fname'].' '.$row['lname'] ?></h4>
                                        <p class="card-text"><?php echo $row['speciality'] ?></p>
                                        <a href="profile.php?id=<?php echo $row["id"] ?>" class="btn">See Profile</a>
                                    </div>
                                </div>
                                <?php 
                               }
                            ?>


                            </div>

                        </div>

                    </div>

                    <!-- Left and right controls -->
                    <a class="carousel-control-prev" href="#demo" data-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </a>
                    <a class="carousel-control-next" href="#demo" data-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </a>

                </div>
            </div>

        </div>

    </div>
</body>
</html>
