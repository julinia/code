<!DOCTYPE html>
<html>
<head>

   <title>Doctor Appointment Form</title>
    <link rel="stylesheet" href="../pannel/doc_app.css">
    <link rel="stylesheet" href="../common.css">
</head>
  <body>

  <div class="header">

<?php

include'../main.php';

?></div>
  
   <div class="mytable">
       <!-- <div class="sign"> -->
       <div class="main">

       <form action="../server/doc_appoinment.php" method="post">
          <table>
            <tr>
            <th colspan="2" class="form_header">Doctor Appointment Form</th>          
            </tr>
            <tr>
            <td>
            <label><b> Patient Name</b></label><br>
            <input type="text" name="pname" placeholder="Enter your fast Name">            
            </td>
            <td>
            <label></label><br>
            <input type="text" name="lname" placeholder="Enter your Last Name">
            </td>
            </tr>           
            <tr>
            <td>
            <label><b>ID</b></label><br>
            <input type="number" name="id" placeholder="">            
            </td>
            <td>
              <!-- <label><b>Password</b></label><br>
              <input type="password" name="password" placeholder="">             -->
              </td>
            </tr> 
            <tr>
            <td>
            <label><b>Age</b></label><br>
            <input type="number" name="age" placeholder="">            
            </td>
            <td>
              <label><b>Weight</b></label><br>
              <input type="number" name="weight" placeholder="">            
              </td>
            </tr>

            <tr>
            <td>
           <label for=""><b>Date of Birth</b></label><br>
           <input type="date" name="date" id="">
           </td>



            <td>
            <label for=""><b>Blood Group</b></label><br>
           <select name="blood" id="">
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
           </select>
            </td>                     
           </tr>
           <tr>
           <td>
            <label><b>Mobile No</b></label><br>
            <input type="number" name="mobile_no" placeholder="">
            </td>
            <td>
            <label><b>Appointment time</b></label><br>
           <select name="atime" id="">
            <option value="Morning_Shift">Morning_Shift</option>
            <option value="Evening_Shift">Evening_Shift</option>
           </select>
            </td>
            </tr>
            <tr>
           <td>
            <label><b>Which doctor would you like to appoientment for your child?</b></label><br>
            <input type="test" name="dname" placeholder="">
            </td>
            </tr>
            <tr>
           <td>
           <label><b>Gender</b></label>
            <input type="radio" name="gender" value="Male">
            <label>Male</label>&nbsp;
            <input type="radio" name="gender" value="Female">
            <label>Female</label>
             </td>
             </tr>
           <tr>
           <td colspan="2" class="submit_btn">
              <input type="submit" name="submit" value="Submit">
           </td>
           </tr>
           </table>
             </form>
             </div>
     <!-- </div> -->
   </div> 
</body>
</html>