<!DOCTYPE html>
<html lang="en">
<head>
  <title>Appointment</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!-- lobstarfonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lobster+Two&display=swap" rel="stylesheet">

  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  
  <script src="https://kit.fontawesome.com/ce8c39f0e8.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
 
  <script src="../jquery.js"></script>
  <link rel="stylesheet" href="fpage.css">
  <style>
      .nav-pills .nav-link.active{
          background: unset;
      }
      .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
    color: #fff;
    background-color: unset;
}
      .dropdown-menu.show {
    display: block;
    background: gray;
          color: white;
}
      .dropdown-item{
          color: white;
      }
      .dropdown-item:hover {
   background: unset;
}
    </style>
</head>
<body >

   <div class="row bg">
     <div class="shadow" >
            <div class="menu-bar1" style=" background:gray;" >
                <marquee behavior="" direction=""><h1 style=" color:rgb(73, 6, 73);"><i> Welcome To Disease Detection System </i></h1></marquee>
            </div>
       
         <div class="container-fluid" style=" background:gray;">
            <nav class="navbar justify-content-center navbar-light  ">

               <ul class="nav nav-pills" role="tablist">

              
                <li class="nav-item ">
                <a class="nav-link text-light" href="../index.php">HOME</a>
               </li>
          

               <!-- <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa-solid fa-house-chimney"> HOME</i>
                HOME
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="#">Link 1</a>
                    <a class="dropdown-item " href="#">Link 2</a>
                    <a class="dropdown-item " href="#">Link 3</a>
                </div>
                </li> -->


                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">ABOUT US</a>

                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/aboutus1.php">ABOUT US</a>
                    <a class="dropdown-item " href="../general/aboutus2.php">MISSION</a>
                   
                </div>
                </li>

                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">SERVICE</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/process.php">PROCESS TO CHECK</a>
                    <a class="dropdown-item " href="../symptom_check/search.php">DISEASE CHECK</a>
                   
                </div>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light" data-toggle="pill" href="appfpage.php">APPOINTMENT</a>
                </li>

                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">REGISTRATION</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/docreg.php">DOCTOR REGISTRATION</a>
                    <!-- <a class="dropdown-item " href="../general/childreg.php">CHILDREN REGISTRATION</a>
                    <a class="dropdown-item " href="../general/doc_app.php">DOCTOR APPOINTMENT</a> -->
                   
                </div>

                </li> 
                
                <li class="nav-item dropdown">
                <a class="nav-link  text-light dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">CONTACT</a>

                <div class="dropdown-menu">
                    <a class="dropdown-item " href="../general/contact.php">CONTACT US</a>
                    <a class="dropdown-item " href="../general/reach.php">REACH US</a>
                   
                   
                </div>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light" href="../login.php">LOG IN</a>
                </li>
                </ul>
          </nav>
          </div>
        
             
                <div class="nipa"  >
                    
                        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item active pl-4">
                                <img src="../picture/77.png" class="d-block w-100" alt="...">
                                <div class="carousel-caption d-none d-md-block">
                                    <h3 class="col-xl-6 text-center " style=" background:#63064c;">Nothing Is More Important Than Wellness</h3>
                                    <p class="col-xl-6 text-center" style=" color:#63064c;"><b>Good health is the most precious thing to us! and that's why we are here to give you the best treatment with the help of the best doctors.</b></p>
                                </div>
                                </div>
                                <div class="carousel-item">
                                <img src="../picture/2.jpg" class="d-block w-100" alt="...">
                                <div class="carousel-caption d-none d-md-block">
                                    <h3 class="col-xl-6 text-center" style=" background:#63064c;">Where There Is Healing There Is Hope</h3>
                                    <p class="col-xl-6 text-center" style=" color:#63064c;"> <b> Experience the best health service with this site! Our doctors are well expert and give you the best service.</b></p>
                                </div>
                                </div>
                                <div class="carousel-item">
                                <img src="../picture/jpg2.png" class="d-block w-100" alt="...">
                                <div class="carousel-caption d-none d-md-block">
                                    <h3 class="col-xl-6 text-center" style=" background:#63064c;">World Class Care Right Where You Need It</h3>
                                    <p class="col-xl-6 text-center" style=" color:#63064c;"> <b>Yes! you are in the right place, We deliver a world-class health service with the help of world-class doctors..</b></p>
                                </div>
                                </div>
                            </div>
                            <button class="carousel-control-prev" type="button" data-target="#carouselExampleCaptions" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-target="#carouselExampleCaptions" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </button>
                        </div>

                </div>
               


            
                <div class="npa2" style=" height: 500px; width:100%; ">
                   <div class="row">
                    <div class="col-6 p-5 mt-3">
                     <img src="../picture/pic6.jpg" class="d-block w-100" style=" height: 400px;" alt="...">
                    </div>
                    <div class="col-6">
                        <p class="p-5 mt-5" style= " text-align: center; font-size: 25px; color: #63064c; font-family: 'Lobster Two', cursive;"> <b>
                        Major causes of death among children vary by age. Children under 5 are
                        especially vulnerable to infectious diseases like malaria, pneumonia,
                        diarrhoea, HIV and tuberculosis. For older children, non-communicable 
                        diseases, injuries and conflict pose significant threats. 
                        Despite being entirely preventable and treatable, common infectious
                        diseases are still killing young children in large numbers. Pneumonia, 
                        diarrhoea and malaria were responsible for approximately 30 per cent 
                        of global deaths among children under the age of 5 in 2019. Children
                        in the world’s poorest regions are disproportionately affected, with
                        infectious diseases particularly prevalent in our country.</b></p>
                    </div>
                   </div>
               </div>


                <div class="npa2" style=" height: 500px; width:100%;">
                   <div class="row">
                   <div class="col-6">
                        <p class="p-5 mt-5" style= " text-align: center;  font-size: 25px;  color: #63064c; font-family: 'Lobster Two', cursive;"><b>
                        Here is a system for children that has been researched on 
                        children's diseases. It is a system that is ready to provide 
                        possible solutions according to the symptoms of children's diseases. 
                        Parents can diagnose the disease based on their child's symptoms at home.
                        And not only that, after the diagnosis of the disease, he is getting
                        some more desirable benefits, such as how the symptoms are actually 
                        coming according to the symptoms of the disease, how to do the treatment, 
                        whether to do the test, when to see the doctor and how to proceed..</b></p>
                    </div>
                    <div class="col-6 p-5 mt-3">
                     <img src="../picture//pic7.jpg" class="d-block w-100" style=" height: 400px;" alt="...">
                    </div>
                   </div>
                </div>


                <div class="npa2" style=" height: 500px; width:100%;">
                   <div class="row">
                    <div class="col-6 p-5 mt-3">
                     <img src="../picture//pic8.jpg" class="d-block w-100" style=" height: 400px;" alt="...">
                    </div>
                    <div class="col-6">
                        <p class="p-5 mt-5" style= " text-align: center; font-size: 25px; color: #63064c; font-family: 'Lobster Two', cursive;"><b>
                        Not only that, here is the list of best doctors.  
                        Award winning and trained doctors can be found here.  
                        Who are able to give proper treatment.  They are able to 
                        give you time according to the schedule. Parents come here to cure 
                        the child's disease, you can choose the doctor according to your choice 
                        and get the benefit of appointment for your child..</b></p>
                    </div>
                   </div>
                </div>


                <div class="nipa3" style="  width:100%;  ">

                <h1 class="ml-5" style=" border-bottom: 2px solid rgb(73, 6, 73); color: rgb(73, 6, 73);">OUR SPECIAL DOCTOR IS HERE</h2> 
                <div class="row">
                  <div class="card-deck mt-5 ml-1">
                      <?php 
                            require ('../db/dbconnect.php');
                      
                    //   $fetchsql = "SELECT * FROM `add_doc` ";
                    $fetchsql = "SELECT * FROM `add_doc` inner join users on users.UID = add_doc.id WHERE status='Approved'";
                      $result = getDataFromDB($fetchsql);
                      
                      foreach($result as $row){
                          ?>
                            <!-- <div class="card" style=" background:#63064c;"> -->
                                <div class="card-body text-center ">
                                        <div class="card ml-6" style="width:250px; height: 400px; border: 4px solid rgb(73, 6, 73);">
                                                <img class="card-img-top " src="../<?php echo $row['picture'] ?>" alt="Card  image" style="width:100%; height: 200px;">
                                                <div class="card-body">
                                                    <h4 class="card-title"><?php echo $row['fname'].' '.$row['lname'] ?></h4>
                                                    <p class="card-text"><?php echo $row['speciality'] ?> </p>
                                                    <a href="profile.php?id=<?php echo $row["id"] ?>" class="btn btn-primary">See Profile</a>
                                                </div>
                                        </div>
                                </div>
                          <!-- </div> -->
                          <?php
                      }
                      ?>

                       
                  </div>
               </div>
            </div>


            </div>

    </div>
</body>

</html>
