<!DOCTYPE html>
<html lang="en">
<head>


        <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


        <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="fpage.css">
        <title>firstpage</title>


</head>
<body>

        <div class="menu-bar">

                <div class="menu-bar1">
                    <marquee behavior="" direction=""><h1><i> Welcome To Disease Detection System </i></h1></marquee>
                </div>
            <ul>
                <li><a href="main2.php">HOME</li>
                <li><a href="#">ABOUT US
                    <div class="sub-menu-1">
                        <ul>
                                    <li><a href="general/aboutus1.php">ABOUT US</a></li>
                                    <li><a href="general/aboutus2.php">MISSION</a></li>
                        </ul>
                    </div>
                </li>
                <li><a href="#">SERVICE
                    <div class="sub-menu-1">
                            <ul>
                            <li><a href="general/process.php">PROCESS TO CHECK</a></li>
                            <li><a href="symptom_check/search.php">DISEASE CHECK</a></li>
                            </ul>
                    </div>
                </li>
                    <!-- <li><a href="#">OUR TEAM</li> -->
                    <li><a href="#">REGISTRATION
                        <div class="sub-menu-1">
                            <ul>
                                <li><a href="general/docreg.php">DOCTOR REGISTRATION</a></li>
                                <!-- <li><a href="general/childreg.php">CHILDREN REGISTRATION</a></li>
                                <li><a href="general/doc_app.php">DOCTOR APPOINTMENT</a></li> -->
                            </ul>
                       </div>
                   </li>
                   <li><a href="#">CONTACT
                        <div class="sub-menu-1">
                        <ul>
                            <li><a href="general/contact.php">CONTACT US</a></li>
                            <li><a href="general/reach.php">REACH US</a></li>
                        </ul>
                        </div>
                   </li>
                   
               <li><a href="login.php">LOG IN</a></li>
           </ul>
        </div>




        <!-- <div class="container-fluid"> -->

            <div class="header1">
              <p>dghfjhfdjnd</p>
               <img src="../appicture/pic2.jpg">
            </div>

            <div class="header2">  
               dfghdh
                <div class="contain">
        

                        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                        <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                        <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            
                        <div class="carousel-item active">
                            
                            <img src="../appicture/pic4.jpg" class="d-block w-100" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                            <h5><b>Why we are different</b></h5>
                            <p>Whatever you need, it has the right solution for your child disease.</p>
                        </div>
                        </div>
                        <div class="carousel-item">
                            <img src="../appicture/pic1.jpg" class="d-block w-100" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                            <h5> <b>Why we are different</b> </h5>
                            <p>Healthcare anytime, anywhere.</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="../appicture/pic5.jpg" class="d-block w-100" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                            <h5><b> Why we are different</b></h5>
                            <p>Healthcare designed around you.</p>
                            </div>
                        </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-target="#carouselExampleCaptions" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-target="#carouselExampleCaptions" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                        </button>
              </div> 

    <!-- </div> -->

</div>

</div>

       
        
</body>
</html>