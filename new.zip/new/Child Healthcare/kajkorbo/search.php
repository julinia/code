<!DOCTYPE html>
<html>
<head>
	<title>Aboutus</title>
	<link rel="stylesheet" type="text/css" href="search.css">
</head>
<body>
<div class="content">
      <h1><b>Welcome to our page. </b></h1>    
      <p><b>This page is able to confirm the exact disease by researching your child's symptoms.
      Then take a look at these rules for research on our page
      </b></p>

      
</div>		

</body>
</html>