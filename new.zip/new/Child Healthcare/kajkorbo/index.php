<!DOCTYPE html>
<html lang="en">
<head>
<!-- <link rel="stylesheet" href="../pannel/docregis.css"> -->
    <link rel="stylesheet" href="common.css">
    <!-- <link rel="stylesheet" href="search.css"> -->
    
    
    <title>Document</title>
</head>
<body>
  <div class="main_bar1">

   <marquee behavior="" direction=""><h1><i> Welcome To Child Healthcare Development Society </i></h1></marquee>

   <?php

include'main.php';

?>
<?php

include'search.php';

?>

   </div>
   
    <section>
  <!-- <img class="mySlides" src="../../picture/2.jpg" style="width:100%"> -->
  <img class="mySlides" src="../picture/login.jpg" style="width:100%">
  <img class="mySlides" src="../picture/login2.jpg" style="width:100%">
</section>



<script>
// Automatic Slideshow - change image every 3 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}
  x[myIndex-1].style.display = "block";
  setTimeout(carousel, 3000);
}
</script>
<?php
      include'sidebar.php';
    
      
    ?>

</body>
</html>