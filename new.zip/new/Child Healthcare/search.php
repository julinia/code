<!DOCTYPE html>
<html>
<head>
	<title>Aboutus</title>
      <!-- lobstarfonts -->
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Lobster+Two&display=swap" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="search.css">
</head>
<body>
                  <div class="content">
                        <h1><b>Welcome to our page. </b></h1>    
                        <p><b>This page is able to confirm the exact disease by researching your child's symptoms.
                        Then take a look at these rules for research on our page
                        </b></p>

                        
                  </div>

                  <div class="con">
                        <div class="nipa1">
                          <img src="picture/pic6.jpg">
                       </div>
                       <div class="nipa2">
                        <p style= "font-family: 'Lobster Two', cursive;">Major causes of death among children vary by age. Children under 5 are
                        especially vulnerable to infectious diseases like malaria, pneumonia,
                        diarrhoea, HIV and tuberculosis. For older children, non-communicable 
                        diseases, injuries and conflict pose significant threats. 
                        Despite being entirely preventable and treatable, common infectious
                        diseases are still killing young children in large numbers. Pneumonia, 
                        diarrhoea and malaria were responsible for approximately 30 per cent 
                        of global deaths among children under the age of 5 in 2019. Children
                        in the world’s poorest regions are disproportionately affected, with
                        infectious diseases particularly prevalent in our country.</p>
                    </div>
                  </div>

                  <div class="con">
                       <div class="nipa2">
                        <p style= "font-family: 'Lobster Two', cursive;"> Here is a system for children that has been researched on 
                        children's diseases. It is a system that is ready to provide 
                        possible solutions according to the symptoms of children's diseases. 
                        Parents can diagnose the disease based on their child's symptoms at home.
                        And not only that, after the diagnosis of the disease, he is getting
                        some more desirable benefits, such as how the symptoms are actually 
                        coming according to the symptoms of the disease, how to do the treatment, 
                        whether to do the test, when to see the doctor and how to proceed.</p>
                    </div>
                    <div class="nipa1">
                          <img src="picture/pic7.jpg">
                       </div>
                  </div>

                  <div class="con">
                        <div class="nipa1">
                          <img src="picture/pic8.jpg">
                       </div>
                       <div class="nipa2">
                        <p style= "font-family: 'Lobster Two', cursive;">
                        Not only that, here is the list of best doctors.  
                        Award winning and trained doctors can be found here.  
                        Who are able to give proper treatment.  They are able to 
                        give you time according to the schedule. Parents come here to cure 
                        the child's disease, you can choose the doctor according to your choice 
                        and get the benefit of appointment for your child.</p>
                    </div>
                  </div>


                  <!-- <div class="container">
                        <p><img src="picture/pic6.jpg">
                        Major causes of death among children vary by age. Children under 5 are
                        especially vulnerable to infectious diseases like malaria, pneumonia,
                        diarrhoea, HIV and tuberculosis. For older children, non-communicable 
                        diseases, injuries and conflict pose significant threats. 
                        Despite being entirely preventable and treatable, common infectious
                        diseases are still killing young children in large numbers. Pneumonia, 
                        diarrhoea and malaria were responsible for approximately 30 per cent 
                        of global deaths among children under the age of 5 in 2019. Children
                        in the world’s poorest regions are disproportionately affected, with
                        infectious diseases particularly prevalent in our country.</p>
                  
                  </div> -->

                 <!-- <div class="npa2" style=" height: 500px; width:100%; ">
                   <div class="row">
                    <div class="col-6 p-5 mt-3">
                     <img src="picture/pic6.jpg" class="d-block w-100" style=" height: 400px;" alt="...">
                    </div>
                    <div class="col-6">
                        <p class="p-5 mt-5" style= " text-align: center; font-size: 25px; color: #63064c; font-family: 'Lobster Two', cursive;"> <b>
                        Major causes of death among children vary by age. Children under 5 are
                        especially vulnerable to infectious diseases like malaria, pneumonia,
                        diarrhoea, HIV and tuberculosis. For older children, non-communicable 
                        diseases, injuries and conflict pose significant threats. 
                        Despite being entirely preventable and treatable, common infectious
                        diseases are still killing young children in large numbers. Pneumonia, 
                        diarrhoea and malaria were responsible for approximately 30 per cent 
                        of global deaths among children under the age of 5 in 2019. Children
                        in the world’s poorest regions are disproportionately affected, with
                        infectious diseases particularly prevalent in our country.</b></p>
                    </div>
                   </div>
               </div>


                <div class="npa2" style=" height: 500px; width:100%;">
                   <div class="row">
                   <div class="col-6">
                        <p class="p-5 mt-5" style= " text-align: center;  font-size: 25px;  color: #63064c; font-family: 'Lobster Two', cursive;"><b>
                        Here is a system for children that has been researched on 
                        children's diseases. It is a system that is ready to provide 
                        possible solutions according to the symptoms of children's diseases. 
                        Parents can diagnose the disease based on their child's symptoms at home.
                        And not only that, after the diagnosis of the disease, he is getting
                        some more desirable benefits, such as how the symptoms are actually 
                        coming according to the symptoms of the disease, how to do the treatment, 
                        whether to do the test, when to see the doctor and how to proceed..</b></p>
                    </div>
                    <div class="col-6 p-5 mt-3">
                     <img src="picture//pic7.jpg" class="d-block w-100" style=" height: 400px;" alt="...">
                    </div>
                   </div>
                </div>


                <div class="npa2" style=" height: 500px; width:100%;">
                   <div class="row">
                    <div class="col-6 p-5 mt-3">
                     <img src="picture//pic8.jpg" class="d-block w-100" style=" height: 400px;" alt="...">
                    </div>
                    <div class="col-6">
                        <p class="p-5 mt-5" style= " text-align: center; font-size: 25px; color: #63064c; font-family: 'Lobster Two', cursive;"><b>
                        Not only that, here is the list of best doctors.  
                        Award winning and trained doctors can be found here.  
                        Who are able to give proper treatment.  They are able to 
                        give you time according to the schedule. Parents come here to cure 
                        the child's disease, you can choose the doctor according to your choice 
                        and get the benefit of appointment for your child..</b></p>
                    </div>
                   </div>
                </div>	 -->
                
             

</body>
</html>