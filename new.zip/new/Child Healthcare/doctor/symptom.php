<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Registration Form</title>
   

<link rel="stylesheet" href="../pannel/admin.css">
<link rel="stylesheet" href="../pannel/adminnav.css">
<style>
     .header2{
         margine: auto;
       height: 18vh;
       width:100%;
     }

     .container{
       height: 82vh;

      overflow-y:auto;
       width:100%;
     }
     
    </style>
</head>
<body>

<div class="container">





<?php

 
  $sql= "SELECT * FROM symptom_add";
   
  include_once '../db/dbconnect.php';

  $container= getDataFromDB($sql);




  ?>
 <h2 align="center">View Disease Information</h2>
  <table border="1px solid black" width="100%" style=" margin-top: 50px;">
      <tr>
          <th>Serial_no</th>
          <th>Symptom_id</th>
          <th>Symptom_name</th>
      </tr>

      <?php 
          foreach($container as $row){
      ?>

              <tr>
                  <td><?php echo $row["Serial_no"] ?></td>
                  <td><?php echo $row["Symptom_id"] ?></td>
                  <td><?php echo $row["Symptom_name"] ?></td>

              </tr>

          <?php


          }
          ?>
  </table>

<?php


?>

</div>
    </body>
</html>