<?php

// SESSION_START();



?>

<!DOCTYPE html>
<html>
<head>
<title>vacation</title>
<link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="vacation.css">
</head>
<body>

<form action="vac_add.php" method="post">

   <div class="row">
        <div class="container mt-5 " style="height:80vh; overflow-y:auto;">
            <h1>Vacation</h1>
            <p>Please fill in this form to create your vacation.</p>
          
                        <label><b>Doctor ID</b></label>
                        <input type="text" value="<?php echo  $_SESSION["doc_id"]?>" readonly placeholder="enter doctor id" name="doc_id" id="" required>

                        <label><b>Vacation Date</b></label>
                        <input type="date" placeholder="enter vacation date" name="date" id="" required>

           
            <label><b>Vacation Title</b></label>
            <input type="text" placeholder="enter vacation title" name="vtitle" id="" required>

            <label><b>Vacation Details</b></label>
            <input type="text" placeholder="enter vacation details" name="vdetails" id="" required>
            <button type="submit" class="registerbtn">Submit</button>
        </div>
   </div>    
</form>

</body>
</html>
