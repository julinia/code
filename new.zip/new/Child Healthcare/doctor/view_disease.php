<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Registration Form</title>
   

<link rel="stylesheet" href="../pannel/admin.css">
<link rel="stylesheet" href="../pannel/adminnav.css">
<style>
     .header2{
         margine: auto;
       height: 18vh;
       width:100%;
     }

     .container{
       height: 82vh;

      overflow-y:auto;
       width:100%;
     }

     .container th{
      text-align: left;
       padding: 12px;

     }


     
    </style>
</head>
<body>

<div class="container">
<?php

 
  $sql= "SELECT * FROM disease_add";
   
  include_once '../db/dbconnect.php';

  $container= getDataFromDB($sql);
  ?>
    <h2 align="center">View Disease Information</h2>
  <table border="1px solid black" width="100%" style=" margin-top: 50px;">
      <tr>
      <th>SerialNo</th>
          <th>Disease_id</th>
          <th>Disease_name</th>
          <th>Symptom1</th>
          <th>Symptom2</th>
          <th>Symptom3</th>
          <th>Symptom4</th>
          <th>Symptom5</th>
          <th>Symptom6</th>
          <th>Symptom7</th>
          <th>Symptom8</th>
          <th>Symptom9</th>
          <th>Symptom10</th>
          <th>Status</th>
          <th>Added_by</th>
          <th>Approved_by</th>
      </tr>

      <?php 
          foreach($container as $row){
      ?>

              <tr>
                  <td><?php echo $row["SerialNo"] ?></td>
                  <td><?php echo $row["Disease_id"] ?></td>
                  <td><?php echo $row["Disease_name"] ?></td>
                  <td><?php echo $row["Symptom1"] ?></td>
                  <td><?php echo $row["Symptom2"] ?></td>
                  <td><?php echo $row["Symptom3"] ?></td>
                  <td><?php echo $row["Symptom4"] ?></td>
                  <td><?php echo $row["Symptom5"] ?></td>
                  <td><?php echo $row["Symptom6"] ?></td>
                  <td><?php echo $row["Symptom7"] ?></td>
                  <td><?php echo $row["Symptom8"] ?></td>
                  <td><?php echo $row["Symptom9"] ?></td>
                  <td><?php echo $row["Symptom10"] ?></td>
                  <td><?php echo $row["Status"] ?></td>
                  <td><?php echo $row["Added_by"] ?></td>
                  <td><?php echo $row["Approved_by"] ?></td> 

              </tr>

          <?php

          }
          ?>
  </table>
</div>
    </body>
</html>

