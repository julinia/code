<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Child App</title>
   

<link rel="stylesheet" href="../pannel/admin.css">
<link rel="stylesheet" href="../pannel/adminnav.css">
<style>
     .header2{
         margine: auto;
       height: 18vh;
       width:100%;
     }

     .container{
       height: 82vh;

      overflow-y:auto;
       width:100%;
     }

     .container th{
      text-align: left;
       padding: 12px;

     }


     
    </style>
</head>
<body>

<div class="container">
<?php

 
  $sql= "SELECT *,app_time.serial_no as SNo FROM child_app INNER JOIN app_time ON app_time.app_id = child_app.app_id WHERE app_time.doc_id = '".$_SESSION["doc_id"]."' AND status = 0";
  
  include_once '../db/dbconnect.php';

  $container= getDataFromDB($sql);
  ?>
    <h2 align="center">View</h2>
  <table border="1px solid black" width="100%" style=" margin-top: 50px;">
  <tr>
           <th>Serial No</th>
           <th>F_Name</th>
          <th>L_Name</th>
          <th>Age</th>
          <th>Weight</th>
          <th>Gender</th>
          <th>Date</th>
          <th>FA_Name</th>
          <th>MO_Name</th>
          <th>Email</th>
          <th>Addres</th>
          <th>Mobile_no</th>
          <th>Patient</th>
          <th>Doc_Id</th>
          <th>Action</th>
      </tr>

      <?php 
          foreach($container as $row){
      ?>

              <tr>
                  <td><?php echo $row["SNo"] ?></td>
                  <td><?php echo $row["fname"] ?></td>
                  <td><?php echo $row["lname"] ?></td>
                  <td><?php echo $row["age"] ?></td>
                  <td><?php echo $row["weight"] ?></td>
                  <td><?php echo $row["gender"] ?></td>
                  <td><?php echo $row["date"] ?></td>
                  <td><?php echo $row["fa_name"] ?></td>
                  <td><?php echo $row["mo_name"] ?></td>
                  <td><?php echo $row["email"] ?></td>
                  <td><?php echo $row["address"] ?></td>
                  <td><?php echo $row["mobile"] ?></td>
                  <td><?php echo $row["patient"] ?></td>
                  <td><?php echo $row["doc_id"] ?></td>
                  <td><a href="visited.php?id=<?php echo $row["SNo"]  ?> ">Visited</a></td>


              </tr>

          <?php

          }
          ?>
  </table>
</div>
    </body>
</html>

