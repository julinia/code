<?php 
session_start();
//echo $_SESSION["Email"];

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Registration Form</title>
   
</head>
<body>  
                   
<div class="container-fluid p-5">
                <div class="row">
                    <?php 
                            include_once ('../db/dbconnect.php');
                      
                      $fetchsql = "SELECT * FROM `add_doc` WHERE email = '".$_SESSION["Email"]."' ";
                      $result = getDataFromDB($fetchsql);
                      
                      foreach($result as $row){
                          ?>
                          
                          
                          
                          <div class="row">
                    <div class="col-6 p-5">
                        <div class="card m-auto" style="width:400px">
                            <img class="card-img-top" src="../<?php echo $row['picture'] ?>" alt="Card image">
                        </div>
                    </div>
                           <div class="col-6 p-5">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo $row['fname'].' '.$row['lname'] ?></h4>
                                <p class="card-text"><?php echo $row['speciality'] ?> </p>
                            </div>
                        </div>
                        
                    </div>
                    
                    <?php
                      }
                              ?>
    </div>
  </div>
                                
            </body>
            </html>