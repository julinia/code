<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Registration Form</title>
   
</head>
<body>


                    <div class="container">
                        <?php  
                        $sql= "SELECT * FROM vac_add where doc_id = '".$_SESSION["doc_id"]."'";
                        
                       include_once '../db/dbconnect.php';

                        $container= getDataFromDB($sql);
                        ?>
                        <h2 align="center">View Vacation Information</h2>
                        <table border="3px solid black" width="100%" style=" margin-top: 50px;">
                            <tr>
                                <th >Doctor ID</th>
                                <th>Vacation Date</th>
                                <th>Vacation Title</th>
                                <th>Vacation Details</th>
                                <th>Action</th>
                            </tr>
                            <?php 
                                foreach($container as $row){
                            ?>
                                    <tr>
                                        <td><?php echo $row["doc_id"] ?></td>
                                        <td><?php echo $row["date"] ?></td>
                                        <td><?php echo $row["vtitle"] ?></td>
                                        <td><?php echo $row["vdetails"] ?></td>
                                        <td><button class="delete"><a href="dlt_vac.php?serial_no=<?php echo $row["serial_no"] ?>">Delete</a></button> </td>

                                    </tr>
                                <?php
                                }
                                ?>
                        </table>


                    </div>

                    
    </body>
</html>