<?php
include_once "../db/db.php";

$doc_id = $_POST["doc_id"];
$date = $_POST["date"];
$vtitle=$_POST["vtitle"];
$vdetails = $_POST["vdetails"];


$query="INSERT INTO `vac_add` (`doc_id`, `date`, `vtitle`, `vdetails`) VALUES ('$doc_id', '$date', '$vtitle', '$vdetails')";


if($con->query($query) === TRUE){
    echo '<script language="javascript">';
    echo 'alert("Info Appruved Successfully"); location.href="nvacation.php"';
    echo '</script>'; }
   else
    {
       
   echo $con->error;       
    }
   

?>