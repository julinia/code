<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>docdashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/ce8c39f0e8.js" crossorigin="anonymous"></script>
</head>
<style>
    .nav ul li{
        font-size:22px;
        color:rgb(73, 6, 73);

        
    }
    
</style>
<body>
    <div class="row">
        <div class="sidebar col-2">
            <div class="row">
               
                 <!-- <div class="sidebar col-10 bg-dark p-4"> -->
                   

                          <?php 
                           
   
                           
                           SESSION_START();

                            $fetchsql = "SELECT * FROM `add_doc` WHERE email = '". $_SESSION["Email"]."'";
                            include_once ('../db/dbconnect.php');
                            $result = getDataFromDB($fetchsql);
                            
                            foreach($result as $row){
                                ?>
                        <div class="sidebar col-12  p-4">

                        <div class="profilebox n-2 m-auto ">

                        <!-- <img src="../picture/nipa.jpg" alt="" > -->
                        <!-- <img class="card-img-top" src="../<?php echo $row['picture'] ?>" alt="Card image"> -->
                        <img src="../<?php echo $row["picture"]; ?>" alt="">

                    </div>

                    <?php
                      }
                      ?>




                    <div class="name mt-4">
                        Doctor
                    </div>



                    <div class="nav">

                    <ul class="nav flex-column">
                    <li class="nav-item">
                            <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-house-user"></i> HOME</a>
                            </li>

                            <li class="nav-item">
                            <a class="nav-link" href="profile.php"><i class="fa-solid fa-address-card"></i> YOUR PROFILE</a>
                            </li>

                            <li class="nav-item">
                            <a class="nav-link" href="child_app2.php"><i class="fa-solid fa-calendar"></i> SHEDULE</a>
                            </li> 
                            <li class="nav-item">
                            <a class="nav-link" href="nvacation.php"><i class="fa-solid fa-tower-observation"></i> VACATION ADD</a>
                            </li>
                            <li class="nav-item">
                            <a class="nav-link" href="vac_add2.php"><i class="fa-solid fa-square-poll-vertical"></i> VACATION RESULT</a>
                            </li>
                            <li class="nav-item">
                            <a class="nav-link" href="../logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> LOG OUT</a>
                            </li>
                        </ul>

                    
                    </div>
                </div>

                <!-- <div class="sidebar col-2 bg-light">

                </div> -->
            </div>



            
        

            <!-- <div class="sidebar col-12 bg-danger "></div> -->
        </div>


        <div class="mainbar col-10 bg-light">

          <div class="row">
            <div class="topbar">
                <div class="row">
                    <div class="col-4 p-2 ">
                        <div class="row">
                            <div class="col-8 ">


                                <div class="input-group">
                                    <div class="input-group-append">
                                        <!-- <span class="input-group-text">
                                           @
                                        </span> -->
                                    </div>
                                    <!-- <input type="text" class="form-control" placeholder="Search"> -->
                                </div>
                      
                        </div>
                               <div class="col-3 ">
                                       <!-- <button class="btn btn-success btn-block">search</button> -->

                                      <!-- <button class="button btn" >Search</button> -->
                               </div>
                    </div>
                    </div>
                    <div class="col-2"></div>

                
                    <div class="col-3 p-2 ">
                        
                                            <ul class="nav nav-pills"><li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Disease Information</a>
                            <div class="dropdown-menu">
                            <a class="dropdown-item" href="disease2.php">Disease</a>
                                <a class="dropdown-item" href="symptom2.php">symptom</a>
                            </li>

                                            
                            <li class="nav-item">
                            <a class="nav-link" href="#">Admim</a>
                            </li>
                            
                            <!-- <li class="nav-item">
                            <a class="nav-link" href="#">Link</a>
                            </li> -->
                            <li class="nav-item">
                            <!-- <a class="nav-link disabled" href="#">Disabled</a> -->
                            </li>
                        </ul>
                    </div>
                    
                        <div class="col-3  profile p-3 ">
                            <img src="../picture/nipa.jpg" alt="" class="flag">
                            nahidaakter@gmail.com
                        </div>
                  
                        
                </div>
            </div>

                        <?php

            include("chid_app.php");

            ?>




                <div class="row">
                  <div class="card-deck">


                    </div>
                  </div>




            </div>



          </div>
        </div>
   

    <!-- <div class="p-5 bg-danger container"></div> -->
    <!-- alada asche -->

    
</body>
</html>