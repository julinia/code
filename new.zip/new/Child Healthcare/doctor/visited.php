<?php
$sql = "UPDATE app_time SET status = 1 WHERE serial_no = '".$_GET['id']."'";
include('../db/db.php');
if($con->query($sql) === TRUE){
    echo '<script language="javascript">';
    echo 'alert("Info Added Successfully"); location.href="child_app2.php"';
    echo '</script>';}
else
 {
    
echo $con->error;     
 }

?>